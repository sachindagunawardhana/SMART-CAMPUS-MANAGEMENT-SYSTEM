package com.scms.service;

import com.scms.dto.MaintenanceDto;
import com.scms.entity.*;
import com.scms.enums.*;
import com.scms.exception.ResourceNotFoundException;
import com.scms.exception.UnauthorizedAccessException;
import com.scms.repository.MaintenanceRequestRepository;
import com.scms.service.impl.MaintenanceServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("MaintenanceService Tests")
class MaintenanceServiceImplTest {

    @Mock private MaintenanceRequestRepository maintenanceRepository;
    @Mock private RoomService                  roomService;
    @Mock private UserService                  userService;
    @Mock private NotificationService          notificationService;

    @InjectMocks
    private MaintenanceServiceImpl maintenanceService;

    private User reporter;
    private User staffUser;
    private Room room;

    @BeforeEach
    void setUp() {
        reporter = new Student("Jaiko", "Student", "student@scms.com",
                "enc", "STU001", "CS", 2);
        reporter.setId(10L);
        ((Student) reporter).setRole(UserRole.STUDENT);

        staffUser = new Staff("Kiyon", "Staff", "staff@scms.com",
                "enc", "EMP001", "Facilities", "Engineer");
        staffUser.setId(2L);
        ((Staff) staffUser).setRole(UserRole.STAFF);

        room = Room.builder().id(1L).roomNumber("LH-101")
                .roomName("Lecture Hall").active(true).build();
    }

    // ── TEST 1: Create maintenance request ─────────────────────────────────

    @Test
    @DisplayName("✅ Should create maintenance request successfully")
    void createRequest_Success() {
        MaintenanceDto.CreateRequest req = new MaintenanceDto.CreateRequest();
        req.setTitle("Broken Projector");
        req.setDescription("Projector in LH-101 is not working.");
        req.setPriority(Priority.HIGH);
        req.setRoomId(1L);

        MaintenanceRequest saved = MaintenanceRequest.builder()
                .id(1L)
                .title(req.getTitle())
                .description(req.getDescription())
                .priority(Priority.HIGH)
                .status(MaintenanceStatus.OPEN)
                .reportedBy(reporter)
                .room(room)
                .build();

        given(userService.getCurrentUser()).willReturn(reporter);
        given(roomService.getRoomEntityById(1L)).willReturn(room);
        given(maintenanceRepository.save(any())).willReturn(saved);

        MaintenanceDto.Response response = maintenanceService.createRequest(req);

        assertThat(response).isNotNull();
        assertThat(response.getTitle()).isEqualTo("Broken Projector");
        assertThat(response.getStatus()).isEqualTo("OPEN");
        assertThat(response.getPriority()).isEqualTo("HIGH");

        verify(notificationService).sendNotification(
                eq(reporter), anyString(), anyString(),
                eq(NotificationType.MAINTENANCE_CREATED), any(), any());
    }

    // ── TEST 2: Assign request to staff ────────────────────────────────────

    @Test
    @DisplayName("✅ Should assign maintenance request to staff")
    void assignRequest_Success() {
        MaintenanceRequest existing = MaintenanceRequest.builder()
                .id(1L).title("Broken Projector")
                .status(MaintenanceStatus.OPEN)
                .reportedBy(reporter)
                .priority(Priority.HIGH)
                .build();

        MaintenanceDto.AssignRequest assignReq = new MaintenanceDto.AssignRequest();
        assignReq.setStaffUserId(2L);

        given(maintenanceRepository.findById(1L)).willReturn(Optional.of(existing));
        given(userService.getUserById(2L)).willReturn(staffUser);
        given(maintenanceRepository.save(any())).willAnswer(inv -> inv.getArgument(0));

        MaintenanceDto.Response response = maintenanceService.assignRequest(1L, assignReq);

        assertThat(response.getStatus()).isEqualTo("ASSIGNED");
        verify(notificationService, times(2)).sendNotification(
                any(), anyString(), anyString(), any(), any(), any());
    }

    // ── TEST 3: Cannot assign to a student ────────────────────────────────

    @Test
    @DisplayName("🚫 Should throw when assigning to a Student")
    void assignRequest_ToStudent_ThrowsException() {
        MaintenanceRequest existing = MaintenanceRequest.builder()
                .id(1L).title("Fix Door").status(MaintenanceStatus.OPEN)
                .reportedBy(reporter).priority(Priority.LOW).build();

        MaintenanceDto.AssignRequest assignReq = new MaintenanceDto.AssignRequest();
        assignReq.setStaffUserId(10L);

        given(maintenanceRepository.findById(1L)).willReturn(Optional.of(existing));
        given(userService.getUserById(10L)).willReturn(reporter); // reporter is a STUDENT

        assertThatThrownBy(() -> maintenanceService.assignRequest(1L, assignReq))
                .isInstanceOf(UnauthorizedAccessException.class);
    }

    // ── TEST 4: Update status to RESOLVED ─────────────────────────────────

    @Test
    @DisplayName("✅ Should resolve maintenance request with notes")
    void updateStatus_Resolved_Success() {
        User admin = new Admin("Charith", "Admin", "admin@scms.com", "enc", "IT");
        admin.setId(1L);
        ((Admin) admin).setRole(UserRole.ADMIN);

        MaintenanceRequest existing = MaintenanceRequest.builder()
                .id(1L).title("Fix HVAC").status(MaintenanceStatus.IN_PROGRESS)
                .reportedBy(reporter).assignedTo(admin).priority(Priority.MEDIUM)
                .build();

        MaintenanceDto.UpdateStatusRequest updateReq = new MaintenanceDto.UpdateStatusRequest();
        updateReq.setStatus("RESOLVED");
        updateReq.setResolutionNotes("HVAC unit was reset and is working normally.");

        given(maintenanceRepository.findById(1L)).willReturn(Optional.of(existing));
        given(userService.getCurrentUser()).willReturn(admin);
        given(maintenanceRepository.save(any())).willAnswer(inv -> inv.getArgument(0));

        MaintenanceDto.Response response = maintenanceService.updateStatus(1L, updateReq);

        assertThat(response.getStatus()).isEqualTo("RESOLVED");
        assertThat(response.getResolutionNotes())
                .isEqualTo("HVAC unit was reset and is working normally.");
    }

    // ── TEST 5: Request not found ──────────────────────────────────────────

    @Test
    @DisplayName("🚫 Should throw ResourceNotFoundException for unknown request ID")
    void getById_NotFound_ThrowsException() {
        given(maintenanceRepository.findById(999L)).willReturn(Optional.empty());

        assertThatThrownBy(() -> maintenanceService.getById(999L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("999");
    }
}
