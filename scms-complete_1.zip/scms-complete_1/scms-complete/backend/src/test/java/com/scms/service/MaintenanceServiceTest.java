package com.scms.service;

import com.scms.dto.MaintenanceDto;
import com.scms.entity.*;
import com.scms.enums.*;
import com.scms.exception.UnauthorizedAccessException;
import com.scms.repository.MaintenanceRequestRepository;
import com.scms.service.impl.MaintenanceServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for MaintenanceServiceImpl.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("MaintenanceService Unit Tests")
class MaintenanceServiceTest {

    @Mock private MaintenanceRequestRepository maintenanceRepository;
    @Mock private UserService                  userService;
    @Mock private RoomService                  roomService;
    @Mock private NotificationService          notificationService;

    @InjectMocks
    private MaintenanceServiceImpl maintenanceService;

    private Staff   testStaff;
    private Admin   testAdmin;
    private Student testStudent;
    private Room    testRoom;

    @BeforeEach
    void setUp() {
        testAdmin = new Admin("Admin", "User", "admin@scms.com", "pwd", "IT");
        testAdmin.setId(1L);
        testAdmin.setRole(UserRole.ADMIN);

        testStaff = new Staff("John", "Staff", "staff@scms.com", "pwd",
                "EMP001", "Facilities", "Technician");
        testStaff.setId(2L);
        testStaff.setRole(UserRole.STAFF);

        testStudent = new Student("Charith", "Student", "charith@scms.com", "pwd",
                "STU001", "CS", 2);
        testStudent.setId(3L);
        testStudent.setRole(UserRole.STUDENT);

        testRoom = Room.builder().id(1L).roomNumber("A101").roomName("Main Hall")
                .roomType(RoomType.LECTURE_HALL).capacity(100).active(true).build();
    }

    // ── TC01: Create maintenance request ──────────────────────────────────

    @Test
    @DisplayName("TC01 - Student should be able to submit a maintenance request")
    void studentShouldCreateMaintenanceRequest() {
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(roomService.getRoomEntityById(1L)).thenReturn(testRoom);
        when(userService.getAllUsers()).thenReturn(List.of(testAdmin));

        MaintenanceRequest saved = MaintenanceRequest.builder()
                .id(10L).title("Broken AC").description("AC not working")
                .priority(Priority.HIGH).status(MaintenanceStatus.OPEN)
                .room(testRoom).reportedBy(testStudent).build();
        when(maintenanceRepository.save(any())).thenReturn(saved);

        MaintenanceDto.CreateRequest req = new MaintenanceDto.CreateRequest();
        req.setTitle("Broken AC");
        req.setDescription("AC not working");
        req.setPriority(Priority.HIGH);
        req.setRoomId(1L);

        MaintenanceDto.Response result = maintenanceService.createRequest(req);

        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo("Broken AC");
        assertThat(result.getStatus()).isEqualTo("OPEN");
        verify(maintenanceRepository).save(any());
        verify(notificationService).broadcastNotification(any(), any(), any(), any(), any(), any());
    }

    // ── TC02: Assign to staff ──────────────────────────────────────────────

    @Test
    @DisplayName("TC02 - Admin should successfully assign maintenance request to staff")
    void adminShouldAssignMaintenanceToStaff() {
        MaintenanceRequest request = MaintenanceRequest.builder()
                .id(10L).title("Broken AC").description("AC not working")
                .priority(Priority.HIGH).status(MaintenanceStatus.OPEN)
                .reportedBy(testStudent).build();

        when(maintenanceRepository.findById(10L)).thenReturn(Optional.of(request));
        when(userService.getUserById(2L)).thenReturn(testStaff);
        when(maintenanceRepository.save(any())).thenReturn(request);

        MaintenanceDto.AssignRequest assignReq = new MaintenanceDto.AssignRequest();
        assignReq.setStaffUserId(2L);

        MaintenanceDto.Response result = maintenanceService.assignRequest(10L, assignReq);

        assertThat(result).isNotNull();
        verify(maintenanceRepository).save(any());
        // Should notify both the assignee and the reporter
        verify(notificationService, times(2)).sendNotification(any(), any(), any(), any(), any(), any());
    }

    // ── TC03: Resolve by assignee ──────────────────────────────────────────

    @Test
    @DisplayName("TC03 - Assigned staff should be able to resolve maintenance request")
    void staffShouldResolveAssignedRequest() {
        MaintenanceRequest request = MaintenanceRequest.builder()
                .id(10L).title("Broken AC").description("AC not working")
                .priority(Priority.HIGH).status(MaintenanceStatus.IN_PROGRESS)
                .reportedBy(testStudent).assignedTo(testStaff).build();

        when(maintenanceRepository.findById(10L)).thenReturn(Optional.of(request));
        when(userService.getCurrentUser()).thenReturn(testStaff);
        when(maintenanceRepository.save(any())).thenReturn(request);

        MaintenanceDto.UpdateStatusRequest statusReq = new MaintenanceDto.UpdateStatusRequest();
        statusReq.setStatus("RESOLVED");
        statusReq.setResolutionNotes("Replaced AC unit filter.");

        MaintenanceDto.Response result = maintenanceService.updateStatus(10L, statusReq);

        assertThat(result).isNotNull();
        verify(maintenanceRepository).save(any());
        // Should send status update + resolved notifications
        verify(notificationService, atLeast(2)).sendNotification(any(), any(), any(), any(), any(), any());
    }

    // ── TC04: Unauthorised status update ──────────────────────────────────

    @Test
    @DisplayName("TC04 - Non-assignee student should NOT update maintenance status")
    void nonAssigneeShouldNotUpdateStatus() {
        // Request assigned to testStaff, but testStudent tries to update
        MaintenanceRequest request = MaintenanceRequest.builder()
                .id(10L).title("Broken AC")
                .status(MaintenanceStatus.ASSIGNED)
                .reportedBy(testStudent).assignedTo(testStaff).build();

        when(maintenanceRepository.findById(10L)).thenReturn(Optional.of(request));
        when(userService.getCurrentUser()).thenReturn(testStudent);  // NOT the assignee

        MaintenanceDto.UpdateStatusRequest statusReq = new MaintenanceDto.UpdateStatusRequest();
        statusReq.setStatus("IN_PROGRESS");

        assertThatThrownBy(() -> maintenanceService.updateStatus(10L, statusReq))
                .isInstanceOf(UnauthorizedAccessException.class);

        verify(maintenanceRepository, never()).save(any());
    }

    // ── TC05: Notification triggered on assignment ─────────────────────────

    @Test
    @DisplayName("TC05 - Assigning a request should trigger notifications to staff and reporter")
    void assignmentShouldTriggerNotifications() {
        MaintenanceRequest request = MaintenanceRequest.builder()
                .id(20L).title("Leaky pipe")
                .priority(Priority.CRITICAL).status(MaintenanceStatus.OPEN)
                .reportedBy(testStudent).build();

        when(maintenanceRepository.findById(20L)).thenReturn(Optional.of(request));
        when(userService.getUserById(2L)).thenReturn(testStaff);
        when(maintenanceRepository.save(any())).thenReturn(request);

        MaintenanceDto.AssignRequest assignReq = new MaintenanceDto.AssignRequest();
        assignReq.setStaffUserId(2L);

        maintenanceService.assignRequest(20L, assignReq);

        // Verify exactly 2 notifications: one to assignee, one to reporter
        verify(notificationService, times(2)).sendNotification(
                any(User.class), anyString(), anyString(), any(), anyLong(), anyString());
    }

    // ── TC06: INTENTIONAL FAIL - wrong expected status ────────────────────

    @Test
    @DisplayName("TC06 [INTENTIONAL FAIL] - Creating request should set status to ASSIGNED (wrong expectation)")
    void intentionalFail_newRequestShouldNotBeAssigned() {
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(userService.getAllUsers()).thenReturn(List.of(testAdmin));

        MaintenanceRequest saved = MaintenanceRequest.builder()
                .id(30L).title("Test").description("Test desc")
                .priority(Priority.LOW).status(MaintenanceStatus.OPEN)
                .reportedBy(testStudent).build();
        when(maintenanceRepository.save(any())).thenReturn(saved);

        MaintenanceDto.CreateRequest req = new MaintenanceDto.CreateRequest();
        req.setTitle("Test");
        req.setDescription("Test desc");
        req.setPriority(Priority.LOW);

        MaintenanceDto.Response result = maintenanceService.createRequest(req);

        // INTENTIONAL FAIL: new requests should be OPEN, not ASSIGNED
        // This test demonstrates the failure detection capability.
        assertThat(result.getStatus())
                .as("New maintenance request should start as OPEN, not ASSIGNED")
                .isEqualTo("ASSIGNED");  // ← This will FAIL — correct status is "OPEN"
    }
}
