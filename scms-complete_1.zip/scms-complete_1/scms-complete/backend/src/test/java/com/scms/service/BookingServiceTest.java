package com.scms.service;

import com.scms.dto.BookingDto;
import com.scms.entity.*;
import com.scms.enums.BookingStatus;
import com.scms.enums.RoomType;
import com.scms.enums.UserRole;
import com.scms.exception.InvalidBookingException;
import com.scms.exception.UnauthorizedAccessException;
import com.scms.repository.BookingRepository;
import com.scms.service.impl.BookingServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for BookingServiceImpl.
 *
 * Tests covered:
 *  1. Successful booking creation
 *  2. Double-booking prevention
 *  3. Booking in the past (invalid)
 *  4. Attendees exceeding room capacity
 *  5. Cancellation by owner
 *  6. Cancellation by non-owner (unauthorised) ← INTENTIONAL FAIL scenario shown
 *  7. Confirm booking — happy path
 *  8. Confirm an already-confirmed booking (invalid state)
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("BookingService Unit Tests")
class BookingServiceTest {

    @Mock private BookingRepository    bookingRepository;
    @Mock private RoomService          roomService;
    @Mock private UserService          userService;
    @Mock private NotificationService  notificationService;

    @InjectMocks
    private BookingServiceImpl bookingService;

    // ── Test Fixtures ──────────────────────────────────────────────────────

    private Room    testRoom;
    private Student testStudent;
    private Admin   testAdmin;

    private static final LocalDateTime NOW       = LocalDateTime.now().plusHours(1);
    private static final LocalDateTime NOW_PLUS2 = NOW.plusHours(2);

    @BeforeEach
    void setUp() {
        testRoom = Room.builder()
                .id(1L)
                .roomNumber("A101")
                .roomName("Main Hall")
                .roomType(RoomType.LECTURE_HALL)
                .capacity(100)
                .active(true)
                .build();

        testStudent = new Student("Charith", "Student", "charith@scms.com",
                "encoded", "STU001", "CS", 2);
        testStudent.setId(10L);
        testStudent.setRole(UserRole.STUDENT);

        testAdmin = new Admin("Admin", "User", "admin@scms.com",
                "encoded", "IT");
        testAdmin.setId(1L);
        testAdmin.setRole(UserRole.ADMIN);
    }

    // ── Test 1: Successful booking ─────────────────────────────────────────

    @Test
    @DisplayName("TC01 - Should create a booking successfully")
    void shouldCreateBookingSuccessfully() {
        // Arrange
        BookingDto.CreateRequest req = createRequest(1L, NOW, NOW_PLUS2, "Lecture", 50);
        when(roomService.getRoomEntityById(1L)).thenReturn(testRoom);
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(bookingRepository.findOverlappingBookings(any(), any(), any(), any()))
                .thenReturn(Collections.emptyList());

        Booking savedBooking = Booking.builder()
                .id(100L).room(testRoom).bookedBy(testStudent)
                .startTime(NOW).endTime(NOW_PLUS2)
                .purpose("Lecture").status(BookingStatus.CONFIRMED)
                .build();
        when(bookingRepository.save(any(Booking.class))).thenReturn(savedBooking);

        // Act
        BookingDto.Response result = bookingService.createBooking(req);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(100L);
        assertThat(result.getStatus()).isEqualTo("CONFIRMED");
        verify(bookingRepository, atLeastOnce()).save(any(Booking.class));
        verify(notificationService, atLeastOnce()).sendNotification(
                any(), any(), any(), any(), any(), any());
    }

    // ── Test 2: Double-booking prevention ─────────────────────────────────

    @Test
    @DisplayName("TC02 - Should throw InvalidBookingException on double booking")
    void shouldPreventDoubleBooking() {
        // Arrange
        BookingDto.CreateRequest req = createRequest(1L, NOW, NOW_PLUS2, "Overlap Test", 20);
        when(roomService.getRoomEntityById(1L)).thenReturn(testRoom);
        when(userService.getCurrentUser()).thenReturn(testStudent);

        Booking existingBooking = Booking.builder()
                .id(99L).room(testRoom)
                .startTime(NOW).endTime(NOW_PLUS2)
                .status(BookingStatus.CONFIRMED).build();
        when(bookingRepository.findOverlappingBookings(any(), any(), any(), any()))
                .thenReturn(List.of(existingBooking));

        // Act & Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("already booked");

        verify(bookingRepository, never()).save(any(Booking.class));
    }

    // ── Test 3: Booking in the past ────────────────────────────────────────

    @Test
    @DisplayName("TC03 - Should reject booking with a past start time")
    void shouldRejectPastBooking() {
        // Arrange — start time is 2 hours ago
        LocalDateTime pastStart = LocalDateTime.now().minusHours(2);
        LocalDateTime pastEnd   = LocalDateTime.now().minusHours(1);
        BookingDto.CreateRequest req = createRequest(1L, pastStart, pastEnd, "Past", 10);

        // Act & Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("past");
    }

    // ── Test 4: Attendees exceed capacity ──────────────────────────────────

    @Test
    @DisplayName("TC04 - Should reject booking when attendees exceed room capacity")
    void shouldRejectWhenAttendeesExceedCapacity() {
        // Arrange — room capacity = 100, requesting 150
        BookingDto.CreateRequest req = createRequest(1L, NOW, NOW_PLUS2, "Over-capacity", 150);
        when(roomService.getRoomEntityById(1L)).thenReturn(testRoom);
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(bookingRepository.findOverlappingBookings(any(), any(), any(), any()))
                .thenReturn(Collections.emptyList());

        // Act & Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("exceed room capacity");
    }

    // ── Test 5: Successful cancellation by owner ───────────────────────────

    @Test
    @DisplayName("TC05 - Owner should be able to cancel their own booking")
    void ownerShouldCancelOwnBooking() {
        // Arrange
        Booking booking = Booking.builder()
                .id(200L).room(testRoom).bookedBy(testStudent)
                .startTime(NOW).endTime(NOW_PLUS2)
                .status(BookingStatus.CONFIRMED).build();

        when(bookingRepository.findById(200L)).thenReturn(Optional.of(booking));
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        BookingDto.CancelRequest cancelReq = new BookingDto.CancelRequest();
        cancelReq.setReason("Change of plans");

        // Act
        BookingDto.Response result = bookingService.cancelBooking(200L, cancelReq);

        // Assert
        assertThat(result).isNotNull();
        verify(bookingRepository).save(any(Booking.class));
        verify(notificationService).sendNotification(any(), any(), any(), any(), any(), any());
    }

    // ── Test 6: Unauthorised cancellation (different user) ─────────────────

    @Test
    @DisplayName("TC06 - Non-owner non-admin should NOT cancel another user's booking")
    void nonOwnerShouldNotCancelBooking() {
        // Arrange — booking owned by testStudent, but another student tries to cancel
        Student otherStudent = new Student("Kiyon", "Other", "Kiyon@scms.com",
                "pwd", "STU999", "Physics", 1);
        otherStudent.setId(99L);
        otherStudent.setRole(UserRole.STUDENT);

        Booking booking = Booking.builder()
                .id(201L).room(testRoom).bookedBy(testStudent)
                .startTime(NOW).endTime(NOW_PLUS2)
                .status(BookingStatus.CONFIRMED).build();

        when(bookingRepository.findById(201L)).thenReturn(Optional.of(booking));
        when(userService.getCurrentUser()).thenReturn(otherStudent);

        BookingDto.CancelRequest cancelReq = new BookingDto.CancelRequest();
        cancelReq.setReason("Trying to steal the booking");

        // Act & Assert
        assertThatThrownBy(() -> bookingService.cancelBooking(201L, cancelReq))
                .isInstanceOf(UnauthorizedAccessException.class);

        verify(bookingRepository, never()).save(any(Booking.class));
    }

    // ── Test 7: Confirm pending booking ────────────────────────────────────

    @Test
    @DisplayName("TC07 - Admin should confirm a PENDING booking")
    void shouldConfirmPendingBooking() {
        // Arrange
        Booking booking = Booking.builder()
                .id(300L).room(testRoom).bookedBy(testStudent)
                .startTime(NOW).endTime(NOW_PLUS2)
                .status(BookingStatus.PENDING).build();

        when(bookingRepository.findById(300L)).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);
        when(userService.getCurrentUser()).thenReturn(testAdmin);

        // Act
        BookingDto.Response result = bookingService.confirmBooking(300L);

        // Assert
        assertThat(result).isNotNull();
        verify(bookingRepository).save(any(Booking.class));
    }

    // ── Test 8: Confirm already-confirmed booking (invalid state) ──────────

    @Test
    @DisplayName("TC08 - Should throw InvalidBookingException when confirming an already-CONFIRMED booking")
    void shouldNotConfirmAlreadyConfirmedBooking() {
        // Arrange
        Booking booking = Booking.builder()
                .id(301L).room(testRoom).bookedBy(testStudent)
                .startTime(NOW).endTime(NOW_PLUS2)
                .status(BookingStatus.CONFIRMED).build();  // Already confirmed!

        when(bookingRepository.findById(301L)).thenReturn(Optional.of(booking));

        // Act & Assert — this IS the intentional "failing scenario":
        // The test verifies the system correctly rejects an invalid state transition.
        assertThatThrownBy(() -> bookingService.confirmBooking(301L))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("PENDING");
    }

    // ── Test 9: Invalid time range (end before start) ──────────────────────

    @Test
    @DisplayName("TC09 - Should reject booking where end time is before start time")
    void shouldRejectInvalidTimeRange() {
        // Arrange — end is before start
        BookingDto.CreateRequest req = createRequest(1L, NOW_PLUS2, NOW, "Invalid range", 10);

        // Act & Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("before end time");
    }

    // ── Test 10: Booking inactive room ────────────────────────────────────

    @Test
    @DisplayName("TC10 - Should reject booking for an inactive room")
    void shouldRejectBookingForInactiveRoom() {
        // Arrange
        testRoom.setActive(false);
        BookingDto.CreateRequest req = createRequest(1L, NOW, NOW_PLUS2, "Inactive room", 10);
        when(roomService.getRoomEntityById(1L)).thenReturn(testRoom);
        when(userService.getCurrentUser()).thenReturn(testStudent);

        // Act & Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("not available");
    }

    // ── Helper ────────────────────────────────────────────────────────────

    private BookingDto.CreateRequest createRequest(Long roomId, LocalDateTime start,
                                                    LocalDateTime end, String purpose,
                                                    int attendees) {
        BookingDto.CreateRequest req = new BookingDto.CreateRequest();
        req.setRoomId(roomId);
        req.setStartTime(start);
        req.setEndTime(end);
        req.setPurpose(purpose);
        req.setAttendeesCount(attendees);
        return req;
    }
}
