// ═══════════════════════════════════════════════════════
// SCMS — Shared Layout Renderer
// ═══════════════════════════════════════════════════════

function renderLayout(pageTitle, pageSubtitle, topbarActions = '') {
  const user = requireAuth();
  if (!user) return;

  const isAdmin   = user.role === 'ADMIN';
  const isStaff   = user.role === 'STAFF';

  const adminLinks = isAdmin ? `
    <div class="nav-section">
      <div class="nav-section-label">Admin</div>
      <a href="/pages/users.html" class="nav-link">
        <span class="icon">👥</span> User Management
      </a>
      <a href="/pages/analytics.html" class="nav-link">
        <span class="icon">📊</span> Analytics
      </a>
    </div>` : '';

  document.body.innerHTML = `
    <aside class="sidebar">
      <div class="sidebar-logo">
        <div class="logo-icon">🏛️</div>
        <span>Smart<br>Campus</span>
      </div>
      <nav>
        <div class="nav-section">
          <div class="nav-section-label">Navigation</div>
          <a href="/pages/dashboard.html" class="nav-link">
            <span class="icon">🏠</span> Dashboard
          </a>
          <a href="/pages/rooms.html" class="nav-link">
            <span class="icon">🚪</span> Rooms
          </a>
          <a href="/pages/bookings.html" class="nav-link">
            <span class="icon">📅</span> Bookings
          </a>
          <a href="/pages/maintenance.html" class="nav-link">
            <span class="icon">🔧</span> Maintenance
          </a>
          <a href="/pages/notifications.html" class="nav-link">
            <span class="icon">🔔</span> Notifications
            <span class="notif-badge" id="notifBadge"></span>
          </a>
        </div>
        ${adminLinks}
      </nav>
      <div class="sidebar-footer">
        <div class="user-info">
          <div class="user-avatar">${user.fullName[0]}</div>
          <div>
            <div class="user-name">${user.fullName}</div>
            <div class="user-role">${user.role.toLowerCase()}</div>
          </div>
        </div>
        <button class="logout-btn" onclick="logout()">⇢ Sign Out</button>
      </div>
    </aside>
    <div class="main">
      <div class="topbar">
        <div>
          <div class="topbar-title">${pageTitle} <span>${pageSubtitle || ''}</span></div>
        </div>
        <div class="topbar-actions">${topbarActions}</div>
      </div>
      <div class="page-content" id="pageContent"></div>
    </div>
  `;

  highlightNav();
  loadUnreadCount();
}
