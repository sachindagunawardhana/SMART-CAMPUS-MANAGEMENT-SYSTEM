// ═══════════════════════════════════════════════════════
// SCMS — Shared API Client & Utilities
// ═══════════════════════════════════════════════════════

const API_BASE = '';

// ─── Auth helpers ─────────────────────────────────────
function getToken()  { return localStorage.getItem('token'); }
function getUser()   { return JSON.parse(localStorage.getItem('user') || 'null'); }
function isLoggedIn(){ return !!getToken(); }
function logout()    { localStorage.clear(); window.location.href = '/'; }

function requireAuth() {
  if (!isLoggedIn()) { window.location.href = '/'; return null; }
  return getUser();
}

// ─── Fetch wrapper ────────────────────────────────────
async function api(path, options = {}) {
  const token = getToken();
  const res = await fetch(API_BASE + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': 'Bearer ' + token } : {}),
      ...(options.headers || {})
    }
  });

  if (res.status === 401) { logout(); return; }

  if (res.status === 204) return null;

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || `Error ${res.status}`);
  return data;
}

const GET    = (path)       => api(path);
const POST   = (path, body) => api(path, { method: 'POST', body: JSON.stringify(body) });
const PUT    = (path, body) => api(path, { method: 'PUT',  body: JSON.stringify(body) });
const PATCH  = (path, body) => api(path, { method: 'PATCH',body: JSON.stringify(body) });
const DELETE = (path, body) => api(path, { method: 'DELETE', body: body ? JSON.stringify(body) : undefined });

// ─── Toast notifications ──────────────────────────────
function toast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;';
    document.body.appendChild(container);
  }
  const colors = { success: '#10b981', error: '#ef4444', warning: '#f59e0b', info: '#6c63ff' };
  const t = document.createElement('div');
  t.style.cssText = `
    background:#1a1d27; border:1px solid ${colors[type]}40;
    color:#e2e8f0; padding:12px 16px; border-radius:10px;
    font-size:14px; max-width:320px; box-shadow:0 4px 20px rgba(0,0,0,.4);
    display:flex; align-items:center; gap:10px;
    animation: slideIn .3s ease;
    border-left: 3px solid ${colors[type]};
  `;
  const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
  t.innerHTML = `<span style="color:${colors[type]};font-weight:bold;">${icons[type]}</span>${message}`;
  container.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, 3500);
}

// ─── Format helpers ───────────────────────────────────
function formatDate(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleDateString('en-US', { year:'numeric', month:'short', day:'numeric' });
}
function formatDateTime(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleString('en-US', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' });
}
function timeAgo(dt) {
  if (!dt) return '';
  const diff = Date.now() - new Date(dt).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h/24)}d ago`;
}

function statusBadge(status) {
  const map = {
    AVAILABLE:       { color: '#10b981', bg: 'rgba(16,185,129,.15)',  label: 'Available' },
    UNDER_MAINTENANCE:{ color: '#f59e0b', bg:'rgba(245,158,11,.15)',  label: 'Maintenance' },
    DEACTIVATED:     { color: '#6b7280', bg: 'rgba(107,114,128,.15)', label: 'Inactive' },
    CONFIRMED:       { color: '#6c63ff', bg: 'rgba(108,99,255,.15)',  label: 'Confirmed' },
    CANCELLED:       { color: '#ef4444', bg: 'rgba(239,68,68,.15)',   label: 'Cancelled' },
    COMPLETED:       { color: '#10b981', bg: 'rgba(16,185,129,.15)',  label: 'Completed' },
    OPEN:            { color: '#f59e0b', bg: 'rgba(245,158,11,.15)',  label: 'Open' },
    ASSIGNED:        { color: '#6c63ff', bg: 'rgba(108,99,255,.15)',  label: 'Assigned' },
    IN_PROGRESS:     { color: '#3b82f6', bg: 'rgba(59,130,246,.15)',  label: 'In Progress' },
    RESOLVED:        { color: '#10b981', bg: 'rgba(16,185,129,.15)',  label: 'Resolved' },
    CLOSED:          { color: '#6b7280', bg: 'rgba(107,114,128,.15)', label: 'Closed' },
  };
  const s = map[status] || { color: '#8892a4', bg: 'rgba(136,146,164,.15)', label: status };
  return `<span style="display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;background:${s.bg};color:${s.color};">
    <span style="width:6px;height:6px;border-radius:50%;background:${s.color};"></span>${s.label}
  </span>`;
}

function priorityBadge(p) {
  const map = {
    LOW:      { color: '#10b981', bg: 'rgba(16,185,129,.15)' },
    MEDIUM:   { color: '#f59e0b', bg: 'rgba(245,158,11,.15)' },
    HIGH:     { color: '#f97316', bg: 'rgba(249,115,22,.15)' },
    CRITICAL: { color: '#ef4444', bg: 'rgba(239,68,68,.15)'  },
  };
  const s = map[p] || { color: '#8892a4', bg: 'rgba(136,146,164,.15)' };
  return `<span style="padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;background:${s.bg};color:${s.color};">${p}</span>`;
}

function roleBadge(role) {
  const map = {
    ADMIN:   { color: '#f87171', bg: 'rgba(239,68,68,.15)'  },
    STAFF:   { color: '#fbbf24', bg: 'rgba(245,158,11,.15)' },
    STUDENT: { color: '#34d399', bg: 'rgba(16,185,129,.15)' },
  };
  const s = map[role] || { color: '#8892a4', bg: 'rgba(136,146,164,.15)' };
  return `<span style="padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;background:${s.bg};color:${s.color};">${role}</span>`;
}

// ─── Modal helper ─────────────────────────────────────
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }

// ─── Sidebar nav highlight ────────────────────────────
function highlightNav() {
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(a => {
    a.classList.toggle('active', a.getAttribute('href') === path);
  });
}

// ─── Unread notification badge ────────────────────────
async function loadUnreadCount() {
  try {
    const data = await GET('/api/notifications/unread/count');
    const badge = document.getElementById('notifBadge');
    if (badge && data.count > 0) {
      badge.textContent = data.count;
      badge.style.display = 'inline-flex';
    }
  } catch(_) {}
}
