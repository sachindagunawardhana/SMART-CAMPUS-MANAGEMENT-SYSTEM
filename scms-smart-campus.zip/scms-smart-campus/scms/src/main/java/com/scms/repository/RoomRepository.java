package com.scms.repository;

import com.scms.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {
    List<Room> findByStatus(Room.RoomStatus status);
    List<Room> findByType(Room.RoomType type);
    Optional<Room> findByRoomNumber(String roomNumber);
    boolean existsByRoomNumber(String roomNumber);

    @Query("SELECT r FROM Room r WHERE r.status = 'AVAILABLE' AND r.capacity >= :minCapacity")
    List<Room> findAvailableRoomsWithCapacity(@Param("minCapacity") int minCapacity);

    @Query("SELECT r, COUNT(b) as bookingCount FROM Room r LEFT JOIN Booking b ON b.room = r GROUP BY r ORDER BY bookingCount DESC")
    List<Object[]> findMostBookedRooms();
}
