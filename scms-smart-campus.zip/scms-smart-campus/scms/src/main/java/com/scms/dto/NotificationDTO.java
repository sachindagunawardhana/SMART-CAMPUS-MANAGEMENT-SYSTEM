package com.scms.dto;

import com.scms.model.Notification;
import lombok.*;
import java.time.LocalDateTime;

public class NotificationDTO {

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id;
        private String title;
        private String message;
        private String type;
        private boolean read;
        private LocalDateTime createdAt;
        private String referenceType;
        private Long referenceId;

        public static Response from(Notification n) {
            return Response.builder()
                .id(n.getId())
                .title(n.getTitle())
                .message(n.getMessage())
                .type(n.getType().name())
                .read(n.isRead())
                .createdAt(n.getCreatedAt())
                .referenceType(n.getReferenceType())
                .referenceId(n.getReferenceId())
                .build();
        }
    }
}
