package com.scms.controller;

import com.scms.dto.RoomDTO;
import com.scms.exception.DuplicateDataException;
import com.scms.exception.ResourceNotFoundException;
import com.scms.model.Room;
import com.scms.service.impl.RoomService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    /** All authenticated users can view rooms */
    @GetMapping
    public ResponseEntity<List<RoomDTO.Response>> getAllRooms() {
        return ResponseEntity.ok(roomService.getAllRooms());
    }

    @GetMapping("/available")
    public ResponseEntity<List<RoomDTO.Response>> getAvailableRooms() {
        return ResponseEntity.ok(roomService.getAvailableRooms());
    }

    @GetMapping("/{id}")
    public ResponseEntity<RoomDTO.Response> getRoomById(@PathVariable Long id) {
        return ResponseEntity.ok(roomService.getRoomById(id));
    }

    @GetMapping("/type/{type}")
    public ResponseEntity<List<RoomDTO.Response>> getRoomsByType(@PathVariable Room.RoomType type) {
        return ResponseEntity.ok(roomService.getRoomsByType(type));
    }

    /** Admin-only operations */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RoomDTO.Response> createRoom(@Valid @RequestBody RoomDTO.Request request) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(roomService.createRoom(request));
        } catch (DuplicateDataException e) {
            throw new RuntimeException(e);
        }
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RoomDTO.Response> updateRoom(@PathVariable Long id,
                                                        @Valid @RequestBody RoomDTO.Request request) throws DuplicateDataException {
        try {
            return ResponseEntity.ok(roomService.updateRoom(id, request));
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @PatchMapping("/{id}/deactivate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RoomDTO.Response> deactivateRoom(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(roomService.deactivateRoom(id));
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @PatchMapping("/{id}/activate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RoomDTO.Response> activateRoom(@PathVariable Long id) {
        return ResponseEntity.ok(roomService.activateRoom(id));
    }

    @PatchMapping("/{id}/maintenance")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RoomDTO.Response> setMaintenance(@PathVariable Long id) {
        return ResponseEntity.ok(roomService.setMaintenanceMode(id));
    }
}
