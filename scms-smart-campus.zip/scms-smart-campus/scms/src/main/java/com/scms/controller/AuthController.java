package com.scms.controller;

import com.scms.dto.AuthDTO;
import com.scms.exception.DuplicateDataException;
import com.scms.model.User;
import com.scms.security.JwtUtils;
import com.scms.service.impl.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin()
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtUtils jwtUtils;
    private final UserService userService;

    @PostMapping("/login")
    public ResponseEntity<AuthDTO.LoginResponse> login(@Valid @RequestBody AuthDTO.LoginRequest request) {
        Authentication auth = authManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        User user = userService.findByUsername(auth.getName());
        String token = jwtUtils.generateToken(user.getUsername(), user.getRole().name(), user.getId());

        return ResponseEntity.ok(AuthDTO.LoginResponse.builder()
            .token(token)
            .tokenType("Bearer")
            .userId(user.getId())
            .username(user.getUsername())
            .fullName(user.getFullName())
            .email(user.getEmail())
            .role(user.getRole().name())
            .dashboardTitle(user.getDashboardTitle())
            .build());
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody AuthDTO.RegisterRequest request) {
        User user = null;
        try {
            user = userService.register(request);
        } catch (DuplicateDataException e) {
            throw new RuntimeException(e);
        }
        return ResponseEntity.ok(java.util.Map.of(
            "message", "User registered successfully",
            "username", user.getUsername(),
            "role", user.getRole().name()
        ));
    }
}
