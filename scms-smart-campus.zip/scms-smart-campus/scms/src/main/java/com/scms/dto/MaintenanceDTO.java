package com.scms.dto;

import com.scms.model.MaintenanceRequest;
import com.scms.model.Notification;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

public class MaintenanceDTO {

    @Getter @Setter
    public static class Request {
        @NotNull  private Long roomId;
        @NotBlank private String title;
        @NotBlank private String description;
        @NotNull  private MaintenanceRequest.Priority priority;
    }

    @Getter @Setter
    public static class AssignRequest {
        @NotNull private Long staffId;
    }

    @Getter @Setter
    public static class UpdateStatusRequest {
        @NotNull  private MaintenanceRequest.RequestStatus status;
        private String resolutionNotes;
    }

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id;
        private Long roomId;
        private String roomNumber;
        private String roomName;
        private Long reportedById;
        private String reportedByName;
        private Long assignedToId;
        private String assignedToName;
        private String title;
        private String description;
        private String priority;
        private String status;
        private LocalDateTime reportedAt;
        private LocalDateTime assignedAt;
        private LocalDateTime resolvedAt;
        private String resolutionNotes;

        public static Response from(MaintenanceRequest req) {
            return Response.builder()
                .id(req.getId())
                .roomId(req.getRoom().getId())
                .roomNumber(req.getRoom().getRoomNumber())
                .roomName(req.getRoom().getName())
                .reportedById(req.getReportedBy().getId())
                .reportedByName(req.getReportedBy().getFullName())
                .assignedToId(req.getAssignedTo() != null ? req.getAssignedTo().getId() : null)
                .assignedToName(req.getAssignedTo() != null ? req.getAssignedTo().getFullName() : null)
                .title(req.getTitle())
                .description(req.getDescription())
                .priority(req.getPriority().name())
                .status(req.getStatus().name())
                .reportedAt(req.getReportedAt())
                .assignedAt(req.getAssignedAt())
                .resolvedAt(req.getResolvedAt())
                .resolutionNotes(req.getResolutionNotes())
                .build();
        }
    }
}
