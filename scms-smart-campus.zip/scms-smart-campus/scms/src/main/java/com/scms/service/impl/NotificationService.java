package com.scms.service.impl;

import com.scms.dto.NotificationDTO;
import com.scms.model.*;
import com.scms.repository.NotificationRepository;
import com.scms.repository.UserRepository;
import com.scms.service.NotificationObserver;
import com.scms.service.NotificationSubject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * OBSERVER PATTERN IMPLEMENTATION:
 * NotificationService acts as both Subject and persistent Observer.
 * It stores notifications in DB and logs them.
 *
 * SINGLETON via Spring @Service.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class NotificationService implements NotificationSubject, NotificationObserver {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    // Observer registry
    private final List<NotificationObserver> observers = new ArrayList<>();

    @Override
    public void addObserver(NotificationObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(NotificationObserver observer) {
        observers.remove(observer);
    }

    /**
     * Notify all registered observers — core Observer pattern dispatch.
     */
    @Override
    public void notifyObservers(User recipient, String title, String message,
                                Notification.NotificationType type, String refType, Long refId) {
        // Persist to DB (this service is its own observer)
        onNotify(recipient, title, message, type, refType, refId);
        // Dispatch to other observers (e.g., email, SMS in production)
        for (NotificationObserver observer : observers) {
            observer.onNotify(recipient, title, message, type, refType, refId);
        }
    }

    /**
     * Persist notification to DB — Observer callback.
     */
    @Override
    public void onNotify(User recipient, String title, String message,
                         Notification.NotificationType type, String refType, Long refId) {
        Notification notification = Notification.builder()
            .recipient(recipient)
            .title(title)
            .message(message)
            .type(type)
            .referenceType(refType)
            .referenceId(refId)
            .build();
        notificationRepository.save(notification);
        log.info("Notification saved for user {}: {}", recipient.getUsername(), title);
    }

    // ─── Query Methods ────────────────────────────────────

    @Transactional(readOnly = true)
    public List<NotificationDTO.Response> getNotificationsForUser(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        return notificationRepository.findByRecipientOrderByCreatedAtDesc(user)
            .stream().map(NotificationDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<NotificationDTO.Response> getUnreadNotifications(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        return notificationRepository.findByRecipientAndReadFalseOrderByCreatedAtDesc(user)
            .stream().map(NotificationDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public long getUnreadCount(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        return notificationRepository.countByRecipientAndReadFalse(user);
    }

    public void markAsRead(Long notificationId, Long userId) {
        Notification notification = notificationRepository.findById(notificationId)
            .orElseThrow(() -> new RuntimeException("Notification not found"));
        if (notification.getRecipient().getId().equals(userId)) {
            notification.setRead(true);
            notification.setReadAt(LocalDateTime.now());
            notificationRepository.save(notification);
        }
    }

    public void markAllAsRead(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        List<Notification> unread = notificationRepository
            .findByRecipientAndReadFalseOrderByCreatedAtDesc(user);
        unread.forEach(n -> {
            n.setRead(true);
            n.setReadAt(LocalDateTime.now());
        });
        notificationRepository.saveAll(unread);
    }
}
