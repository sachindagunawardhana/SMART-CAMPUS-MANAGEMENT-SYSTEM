package com.scms.exception;

import jakarta.transaction.SystemException;

public class InvalidBookingException extends SystemException {
    public InvalidBookingException(String message) {
        super();
    }

    public String getErrorCode() {
        return "";
    }
}
