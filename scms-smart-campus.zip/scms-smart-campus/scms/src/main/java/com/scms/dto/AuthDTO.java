package com.scms.dto;

import com.scms.model.User;
import jakarta.validation.constraints.*;
import lombok.*;

public class AuthDTO {

    @Getter @Setter
    public static class LoginRequest {
        @NotBlank(message = "Username is required")
        private String username;
        @NotBlank(message = "Password is required")
        private String password;
    }

    @Getter @Setter @Builder
    public static class LoginResponse {
        private String token;
        private String tokenType;
        private Long userId;
        private String username;
        private String fullName;
        private String email;
        private String role;
        private String dashboardTitle;
    }

    @Getter @Setter
    public static class RegisterRequest {
        @NotBlank private String username;
        @NotBlank @Size(min = 6) private String password;
        @NotBlank private String fullName;
        @Email @NotBlank private String email;
        @NotNull private User.Role role;
        private String studentId;
        private String faculty;
        private String staffId;
        private String position;
        private String department;
    }
}
