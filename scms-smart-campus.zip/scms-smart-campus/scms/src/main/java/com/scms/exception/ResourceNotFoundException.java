package com.scms.exception;

import jakarta.transaction.SystemException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends SystemException {
    public ResourceNotFoundException(String resource, Long id) {
        super();
    }
    public ResourceNotFoundException(String message) {
        super();
    }

    public String getErrorCode() {
        return "";
    }
}
