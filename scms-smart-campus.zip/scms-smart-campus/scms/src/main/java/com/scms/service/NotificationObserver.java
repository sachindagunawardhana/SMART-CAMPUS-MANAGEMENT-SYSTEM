package com.scms.service;

import com.scms.model.*;

/**
 * OBSERVER PATTERN — Observer interface.
 * Implemented by any class that wants to receive notifications.
 */
public interface NotificationObserver {
    void onNotify(User recipient, String title, String message,
                  Notification.NotificationType type, String refType, Long refId);
}
