package com.scms.service;

import com.scms.model.*;

/**
 * OBSERVER PATTERN — Subject interface.
 * Any service that triggers notifications implements this.
 */
public interface NotificationSubject {
    void addObserver(NotificationObserver observer);
    void removeObserver(NotificationObserver observer);
    void notifyObservers(User recipient, String title, String message,
                         Notification.NotificationType type, String refType, Long refId);
}
