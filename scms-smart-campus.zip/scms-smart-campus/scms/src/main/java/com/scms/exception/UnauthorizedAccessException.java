package com.scms.exception;

import jakarta.transaction.SystemException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class UnauthorizedAccessException extends SystemException {
    public UnauthorizedAccessException(String message) {
        super();
    }

    public String getErrorCode() {
        return "";
    }
}
