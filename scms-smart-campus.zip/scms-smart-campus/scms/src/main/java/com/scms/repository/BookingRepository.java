package com.scms.repository;

import com.scms.model.Booking;
import com.scms.model.Room;
import com.scms.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByBookedByOrderByStartTimeDesc(User user);
    List<Booking> findByRoomOrderByStartTimeDesc(Room room);
    List<Booking> findByStatus(Booking.BookingStatus status);

    @Query("SELECT b FROM Booking b WHERE b.room = :room " +
           "AND b.status = 'CONFIRMED' " +
           "AND b.startTime < :endTime AND b.endTime > :startTime")
    List<Booking> findConflictingBookings(
        @Param("room") Room room,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    @Query("SELECT b FROM Booking b WHERE b.bookedBy = :user AND b.status = 'CONFIRMED' AND b.endTime > :now ORDER BY b.startTime ASC")
    List<Booking> findUpcomingBookingsByUser(@Param("user") User user, @Param("now") LocalDateTime now);

    List<Booking> findByBookedByAndStatus(User user, Booking.BookingStatus status);
}
