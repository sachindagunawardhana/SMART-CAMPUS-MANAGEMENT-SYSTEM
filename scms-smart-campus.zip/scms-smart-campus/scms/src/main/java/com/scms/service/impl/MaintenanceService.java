package com.scms.service.impl;

import com.scms.dto.MaintenanceDTO;
import com.scms.exception.*;
import com.scms.model.*;
import com.scms.repository.MaintenanceRequestRepository;
import com.scms.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class MaintenanceService {

    private final MaintenanceRequestRepository maintenanceRepository;
    private final UserRepository userRepository;
    private final RoomService roomService;
    private final NotificationService notificationService;

    public MaintenanceDTO.Response createRequest(Long userId, MaintenanceDTO.Request request) throws ResourceNotFoundException {
        User reporter = findUserOrThrow(userId);
        Room room = roomService.findRoomOrThrow(request.getRoomId());

        MaintenanceRequest mr = MaintenanceRequest.builder()
            .room(room)
            .reportedBy(reporter)
            .title(request.getTitle())
            .description(request.getDescription())
            .priority(request.getPriority())
            .status(MaintenanceRequest.RequestStatus.OPEN)
            .build();

        MaintenanceRequest saved = maintenanceRepository.save(mr);
        log.info("Maintenance request #{} created for room {}", saved.getId(), room.getRoomNumber());

        // Notify the reporter
        notificationService.notifyObservers(
            reporter,
            "Maintenance Request Submitted",
            "Your maintenance request for room " + room.getRoomNumber() + " has been received.",
            Notification.NotificationType.MAINTENANCE_SUBMITTED,
            "MAINTENANCE", saved.getId()
        );

        // Notify all admins
        userRepository.findByRole(User.Role.ADMIN).forEach(admin ->
            notificationService.notifyObservers(
                admin,
                "New Maintenance Request",
                request.getPriority() + " priority issue in " + room.getRoomNumber() + ": " + request.getTitle(),
                Notification.NotificationType.MAINTENANCE_SUBMITTED,
                "MAINTENANCE", saved.getId()
            )
        );

        return MaintenanceDTO.Response.from(saved);
    }

    public MaintenanceDTO.Response assignRequest(Long requestId, Long adminId, MaintenanceDTO.AssignRequest assignReq) throws Throwable {
        User admin = findUserOrThrow(adminId);
        if (admin.getRole() != User.Role.ADMIN) {
            throw new Throwable("Only admins can assign maintenance requests");
        }

        MaintenanceRequest mr = findRequestOrThrow(requestId);
        User staff = findUserOrThrow(assignReq.getStaffId());

        if (staff.getRole() != User.Role.STAFF) {
            throw new InvalidBookingException("Maintenance requests can only be assigned to staff members");
        }

        mr.setAssignedTo(staff);
        mr.setStatus(MaintenanceRequest.RequestStatus.ASSIGNED);
        mr.setAssignedAt(LocalDateTime.now());

        MaintenanceRequest saved = maintenanceRepository.save(mr);

        // Notify the assigned staff
        notificationService.notifyObservers(
            staff,
            "Maintenance Request Assigned",
            "You have been assigned maintenance request #" + requestId + ": " + mr.getTitle(),
            Notification.NotificationType.MAINTENANCE_ASSIGNED,
            "MAINTENANCE", requestId
        );

        // Notify the reporter
        notificationService.notifyObservers(
            mr.getReportedBy(),
            "Maintenance Request Assigned",
            "Your request has been assigned to " + staff.getFullName(),
            Notification.NotificationType.MAINTENANCE_UPDATED,
            "MAINTENANCE", requestId
        );

        return MaintenanceDTO.Response.from(saved);
    }

    public MaintenanceDTO.Response updateStatus(Long requestId, Long userId, MaintenanceDTO.UpdateStatusRequest req) throws Throwable {
        User user = findUserOrThrow(userId);
        MaintenanceRequest mr = findRequestOrThrow(requestId);

        // Only assigned staff, the reporter, or admin can update
        boolean isAssigned = mr.getAssignedTo() != null && mr.getAssignedTo().getId().equals(userId);
        boolean isAdmin = user.getRole() == User.Role.ADMIN;
        if (!isAssigned && !isAdmin) {
            throw new Throwable("You are not authorized to update this request");
        }

        mr.setStatus(req.getStatus());
        if (req.getResolutionNotes() != null) {
            mr.setResolutionNotes(req.getResolutionNotes());
        }
        if (req.getStatus() == MaintenanceRequest.RequestStatus.RESOLVED
                || req.getStatus() == MaintenanceRequest.RequestStatus.CLOSED) {
            mr.setResolvedAt(LocalDateTime.now());
            // Restore room to available if it was under maintenance
            Room room = mr.getRoom();
            if (room.getStatus() == Room.RoomStatus.UNDER_MAINTENANCE) {
                room.setStatus(Room.RoomStatus.AVAILABLE);
                roomService.findRoomOrThrow(room.getId()); // triggers save via dirty check
            }
        }
        if (req.getStatus() == MaintenanceRequest.RequestStatus.IN_PROGRESS) {
            // Mark room as under maintenance
            roomService.setMaintenanceMode(mr.getRoom().getId());
        }

        MaintenanceRequest saved = maintenanceRepository.save(mr);

        // Notify reporter of status change
        notificationService.notifyObservers(
            mr.getReportedBy(),
            "Maintenance Update",
            "Request #" + requestId + " status changed to: " + req.getStatus().name(),
            Notification.NotificationType.MAINTENANCE_UPDATED,
            "MAINTENANCE", requestId
        );

        if (req.getStatus() == MaintenanceRequest.RequestStatus.RESOLVED) {
            notificationService.notifyObservers(
                mr.getReportedBy(),
                "Maintenance Resolved",
                "Your maintenance request for " + mr.getRoom().getRoomNumber() + " has been resolved.",
                Notification.NotificationType.MAINTENANCE_RESOLVED,
                "MAINTENANCE", requestId
            );
        }

        return MaintenanceDTO.Response.from(saved);
    }

    @Transactional(readOnly = true)
    public List<MaintenanceDTO.Response> getAllRequests() {
        return maintenanceRepository.findAllByOrderByReportedAtDesc().stream()
            .map(MaintenanceDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<MaintenanceDTO.Response> getActiveRequests() {
        return maintenanceRepository.findActiveRequestsByPriority().stream()
            .map(MaintenanceDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<MaintenanceDTO.Response> getMyRequests(Long userId) throws ResourceNotFoundException {
        User user = findUserOrThrow(userId);
        return maintenanceRepository.findByReportedByOrderByReportedAtDesc(user).stream()
            .map(MaintenanceDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<MaintenanceDTO.Response> getAssignedToMe(Long userId) throws ResourceNotFoundException {
        User user = findUserOrThrow(userId);
        return maintenanceRepository.findByAssignedToOrderByReportedAtDesc(user).stream()
            .map(MaintenanceDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public MaintenanceDTO.Response getById(Long id) throws ResourceNotFoundException {
        return MaintenanceDTO.Response.from(findRequestOrThrow(id));
    }

    private MaintenanceRequest findRequestOrThrow(Long id) throws ResourceNotFoundException {
        return maintenanceRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("MaintenanceRequest", id));
    }

    private User findUserOrThrow(Long id) throws ResourceNotFoundException {
        return userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }
}
