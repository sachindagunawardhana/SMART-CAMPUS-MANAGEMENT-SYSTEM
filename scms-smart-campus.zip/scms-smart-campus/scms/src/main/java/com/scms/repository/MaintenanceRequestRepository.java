package com.scms.repository;

import com.scms.model.MaintenanceRequest;
import com.scms.model.Room;
import com.scms.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MaintenanceRequestRepository extends JpaRepository<MaintenanceRequest, Long> {
    List<MaintenanceRequest> findByStatus(MaintenanceRequest.RequestStatus status);
    List<MaintenanceRequest> findByReportedByOrderByReportedAtDesc(User user);
    List<MaintenanceRequest> findByAssignedToOrderByReportedAtDesc(User user);
    List<MaintenanceRequest> findByRoom(Room room);

    @Query("SELECT m FROM MaintenanceRequest m WHERE m.status NOT IN ('RESOLVED','CLOSED') ORDER BY m.priority DESC, m.reportedAt ASC")
    List<MaintenanceRequest> findActiveRequestsByPriority();

    List<MaintenanceRequest> findAllByOrderByReportedAtDesc();
}
