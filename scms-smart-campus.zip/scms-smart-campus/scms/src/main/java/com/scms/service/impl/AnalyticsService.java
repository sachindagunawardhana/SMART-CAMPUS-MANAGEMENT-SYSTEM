package com.scms.service.impl;

import com.scms.dto.AnalyticsDTO;
import com.scms.model.Booking;
import com.scms.model.MaintenanceRequest;
import com.scms.model.Room;
import com.scms.repository.BookingRepository;
import com.scms.repository.MaintenanceRequestRepository;
import com.scms.repository.RoomRepository;
import com.scms.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AnalyticsService {

    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;
    private final MaintenanceRequestRepository maintenanceRepository;
    private final UserRepository userRepository;

    public AnalyticsDTO.DashboardStats getDashboardStats() {
        long totalRooms     = roomRepository.count();
        long availableRooms = roomRepository.findByStatus(Room.RoomStatus.AVAILABLE).size();
        long totalBookings  = bookingRepository.count();
        long activeBookings = bookingRepository.findByStatus(Booking.BookingStatus.CONFIRMED)
                                .stream()
                                .filter(b -> b.getEndTime().isAfter(LocalDateTime.now()))
                                .count();
        long openMaint      = maintenanceRepository.findActiveRequestsByPriority().size();
        long totalUsers     = userRepository.count();

        List<AnalyticsDTO.RoomBookingStats> topRooms = roomRepository.findMostBookedRooms()
            .stream()
            .limit(5)
            .map(row -> new AnalyticsDTO.RoomBookingStats(
                ((Room) row[0]).getRoomNumber(),
                ((Room) row[0]).getName(),
                (Long) row[1]
            ))
            .collect(Collectors.toList());

        return AnalyticsDTO.DashboardStats.builder()
            .totalRooms(totalRooms)
            .availableRooms(availableRooms)
            .totalBookings(totalBookings)
            .activeBookings(activeBookings)
            .openMaintenanceRequests(openMaint)
            .totalUsers(totalUsers)
            .topBookedRooms(topRooms)
            .build();
    }
}
