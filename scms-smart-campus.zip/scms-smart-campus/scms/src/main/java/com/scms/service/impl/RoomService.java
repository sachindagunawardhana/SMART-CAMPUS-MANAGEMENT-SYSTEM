package com.scms.service.impl;

import com.scms.dto.RoomDTO;
import com.scms.exception.*;
import com.scms.model.Room;
import com.scms.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class RoomService {

    private final RoomRepository roomRepository;

    public RoomDTO.Response createRoom(RoomDTO.Request request) throws DuplicateDataException {
        if (roomRepository.existsByRoomNumber(request.getRoomNumber())) {
            throw new DuplicateDataException("Room with number " + request.getRoomNumber() + " already exists");
        }
        // FACTORY PATTERN — delegate object creation
        Room room = RoomFactory.createRoom(request);
        Room saved = roomRepository.save(room);
        log.info("Room created: {}", saved.getRoomNumber());
        return RoomDTO.Response.from(saved);
    }

    public RoomDTO.Response updateRoom(Long id, RoomDTO.Request request) throws DuplicateDataException, ResourceNotFoundException {
        Room room = findRoomOrThrow(id);
        if (!room.getRoomNumber().equals(request.getRoomNumber())
                && roomRepository.existsByRoomNumber(request.getRoomNumber())) {
            throw new DuplicateDataException("Room number already in use: " + request.getRoomNumber());
        }
        room.setRoomNumber(request.getRoomNumber());
        room.setName(request.getName());
        room.setType(request.getType());
        room.setCapacity(request.getCapacity());
        room.setBuilding(request.getBuilding());
        room.setFloor(request.getFloor());
        room.setDescription(request.getDescription());
        room.setHasProjector(request.isHasProjector());
        room.setHasWhiteboard(request.isHasWhiteboard());
        room.setHasAC(request.isHasAC());
        return RoomDTO.Response.from(roomRepository.save(room));
    }

    public RoomDTO.Response deactivateRoom(Long id) throws ResourceNotFoundException {
        Room room = findRoomOrThrow(id);
        room.setStatus(Room.RoomStatus.DEACTIVATED);
        return RoomDTO.Response.from(roomRepository.save(room));
    }

    public RoomDTO.Response setMaintenanceMode(Long id) {
        Room room = null;
        try {
            room = findRoomOrThrow(id);
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
        room.setStatus(Room.RoomStatus.UNDER_MAINTENANCE);
        return RoomDTO.Response.from(roomRepository.save(room));
    }

    public RoomDTO.Response activateRoom(Long id) {
        Room room = null;
        try {
            room = findRoomOrThrow(id);
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
        room.setStatus(Room.RoomStatus.AVAILABLE);
        return RoomDTO.Response.from(roomRepository.save(room));
    }

    @Transactional(readOnly = true)
    public List<RoomDTO.Response> getAllRooms() {
        return roomRepository.findAll().stream()
            .map(RoomDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<RoomDTO.Response> getAvailableRooms() {
        return roomRepository.findByStatus(Room.RoomStatus.AVAILABLE).stream()
            .map(RoomDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public RoomDTO.Response getRoomById(Long id) {
        try {
            return RoomDTO.Response.from(findRoomOrThrow(id));
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Transactional(readOnly = true)
    public List<RoomDTO.Response> getRoomsByType(Room.RoomType type) {
        return roomRepository.findByType(type).stream()
            .map(RoomDTO.Response::from).collect(Collectors.toList());
    }

    public Room findRoomOrThrow(Long id) throws ResourceNotFoundException {
        return roomRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Room", id));
    }
}
