package com.scms.config;

import com.scms.dto.AuthDTO;
import com.scms.dto.RoomDTO;
import com.scms.model.Room;
import com.scms.model.User;
import com.scms.service.impl.RoomService;
import com.scms.service.impl.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Seeds demo data on startup so the UI is immediately usable.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final UserService userService;
    private final RoomService roomService;

    @Override
    public void run(String... args) {
        log.info("=== Seeding demo data ===");
        seedUsers();
        seedRooms();
        log.info("=== Demo data ready ===");
        log.info("Login: admin/admin123 | staff/staff123 | student/student123");
    }

    private void seedUsers() {
        createUser("admin",   "admin123",   "Admin User",      "admin@campus.edu",   User.Role.ADMIN);
        createUser("staff",   "staff123",   "Jane Staff",      "staff@campus.edu",   User.Role.STAFF);
        createUser("student", "student123", "John Student",    "student@campus.edu", User.Role.STUDENT);
        createUser("staff2",  "staff123",   "Bob Technician",  "staff2@campus.edu",  User.Role.STAFF);
        createUser("student2","student123", "Alice Scholar",   "student2@campus.edu",User.Role.STUDENT);
    }

    private void createUser(String username, String password, String fullName, String email, User.Role role) {
        try {
            AuthDTO.RegisterRequest req = new AuthDTO.RegisterRequest();
            req.setUsername(username);
            req.setPassword(password);
            req.setFullName(fullName);
            req.setEmail(email);
            req.setRole(role);
            userService.register(req);
        } catch (Exception e) {
            log.debug("User {} already exists, skipping", username);
        }
    }

    private void seedRooms() {
        createRoom("LH-101", "Main Lecture Hall",    Room.RoomType.LECTURE_HALL, 200, "Block A", "1", true,  true,  true);
        createRoom("SR-201", "Seminar Room A",       Room.RoomType.SEMINAR_ROOM, 30,  "Block B", "2", true,  true,  true);
        createRoom("LAB-301","Computer Lab",         Room.RoomType.LAB,          40,  "Block C", "3", true,  false, true);
        createRoom("MR-401", "Board Meeting Room",   Room.RoomType.MEETING_ROOM, 15,  "Block D", "4", true,  true,  true);
        createRoom("STU-501","Quiet Study Room",     Room.RoomType.STUDY_ROOM,   20,  "Block E", "5", false, true,  false);
        createRoom("AUD-001","Grand Auditorium",     Room.RoomType.AUDITORIUM,   500, "Main",    "G", true,  false, true);
        createRoom("SR-202", "Seminar Room B",       Room.RoomType.SEMINAR_ROOM, 25,  "Block B", "2", true,  true,  false);
        createRoom("LAB-302","Physics Lab",          Room.RoomType.LAB,          35,  "Block C", "3", false, true,  true);
    }

    private void createRoom(String number, String name, Room.RoomType type, int capacity,
                            String building, String floor,
                            boolean projector, boolean whiteboard, boolean ac) {
        try {
            RoomDTO.Request req = new RoomDTO.Request();
            req.setRoomNumber(number);
            req.setName(name);
            req.setType(type);
            req.setCapacity(capacity);
            req.setBuilding(building);
            req.setFloor(floor);
            req.setHasProjector(projector);
            req.setHasWhiteboard(whiteboard);
            req.setHasAC(ac);
            roomService.createRoom(req);
        } catch (Exception e) {
            log.debug("Room {} already exists, skipping", number);
        }
    }
}
