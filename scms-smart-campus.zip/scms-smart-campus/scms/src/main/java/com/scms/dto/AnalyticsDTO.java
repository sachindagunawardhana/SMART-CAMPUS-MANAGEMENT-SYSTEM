package com.scms.dto;

import lombok.*;
import java.util.List;

public class AnalyticsDTO {

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class DashboardStats {
        private long totalRooms;
        private long availableRooms;
        private long totalBookings;
        private long activeBookings;
        private long openMaintenanceRequests;
        private long totalUsers;
        private List<RoomBookingStats> topBookedRooms;
    }

    @Getter @Setter @Builder @AllArgsConstructor @NoArgsConstructor
    public static class RoomBookingStats {
        private String roomNumber;
        private String roomName;
        private long bookingCount;
    }
}
