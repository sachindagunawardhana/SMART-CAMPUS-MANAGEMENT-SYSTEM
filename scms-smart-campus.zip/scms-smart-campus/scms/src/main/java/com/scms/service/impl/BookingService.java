package com.scms.service.impl;

import com.scms.dto.BookingDTO;
import com.scms.exception.*;
import com.scms.model.*;
import com.scms.repository.BookingRepository;
import com.scms.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * FACADE PATTERN (Structural):
 * BookingService acts as a Facade hiding the complexity of:
 * - Conflict detection
 * - Room availability checks
 * - Notification dispatch
 * - Booking lifecycle management
 *
 * Clients just call book(), cancel() without knowing internals.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final RoomService roomService;
    private final NotificationService notificationService;

    /**
     * FACADE: Single entry point for booking a room.
     * Internally: validates, checks conflicts, persists, notifies.
     */
    public BookingDTO.Response createBooking(Long userId, BookingDTO.Request request) throws Throwable {
        User user = findUserOrThrow(userId);
        Room room = roomService.findRoomOrThrow(request.getRoomId());

        // Validate room availability
        if (room.getStatus() != Room.RoomStatus.AVAILABLE) {
            throw new Throwable("Room " + room.getRoomNumber() + " is not available for booking");
        }

        // Validate time range
        if (!request.getStartTime().isBefore(request.getEndTime())) {
            throw new Throwable("Start time must be before end time");
        }
        if (request.getStartTime().isBefore(LocalDateTime.now())) {
            throw new Throwable("Cannot book a room in the past");
        }

        // Check attendees vs capacity
        if (request.getAttendeesCount() > room.getCapacity()) {
            throw new Throwable(
                "Attendees (" + request.getAttendeesCount() + ") exceed room capacity (" + room.getCapacity() + ")"
            );
        }

        // Check double booking — prevents conflicts
        List<Booking> conflicts = bookingRepository.findConflictingBookings(
            room, request.getStartTime(), request.getEndTime()
        );
        if (!conflicts.isEmpty()) {
            throw new Throwable(
                "Room " + room.getRoomNumber() + " is already booked during this time slot"
            );
        }

        Booking booking = Booking.builder()
            .room(room)
            .bookedBy(user)
            .title(request.getTitle())
            .description(request.getDescription())
            .startTime(request.getStartTime())
            .endTime(request.getEndTime())
            .attendeesCount(request.getAttendeesCount())
            .status(Booking.BookingStatus.CONFIRMED)
            .build();

        Booking saved = bookingRepository.save(booking);
        log.info("Booking created: {} for room {}", saved.getId(), room.getRoomNumber());

        // OBSERVER: Notify user of booking confirmation
        notificationService.notifyObservers(
            user,
            "Booking Confirmed",
            "Your booking for " + room.getName() + " on " + request.getStartTime().toLocalDate() + " is confirmed.",
            Notification.NotificationType.BOOKING_CONFIRMED,
            "BOOKING", saved.getId()
        );

        return BookingDTO.Response.from(saved);
    }

    /**
     * FACADE: Single entry point for cancelling a booking.
     */
    public BookingDTO.Response cancelBooking(Long bookingId, Long userId, String reason) throws Throwable {
        Booking booking = findBookingOrThrow(bookingId);
        User requestingUser = findUserOrThrow(userId);

        // Only the owner or admin can cancel
        boolean isOwner = booking.getBookedBy().getId().equals(userId);
        boolean isAdmin = requestingUser.getRole() == User.Role.ADMIN;
        if (!isOwner && !isAdmin) {
            throw new Throwable("You are not authorized to cancel this booking");
        }

        if (booking.getStatus() != Booking.BookingStatus.CONFIRMED) {
            throw new Throwable("Only confirmed bookings can be cancelled");
        }

        booking.setStatus(Booking.BookingStatus.CANCELLED);
        booking.setCancelledAt(LocalDateTime.now());
        booking.setCancellationReason(reason);
        Booking saved = bookingRepository.save(booking);

        // OBSERVER: Notify booking owner
        notificationService.notifyObservers(
            booking.getBookedBy(),
            "Booking Cancelled",
            "Your booking for " + booking.getRoom().getName() + " has been cancelled. Reason: " + reason,
            Notification.NotificationType.BOOKING_CANCELLED,
            "BOOKING", bookingId
        );

        return BookingDTO.Response.from(saved);
    }

    @Transactional(readOnly = true)
    public List<BookingDTO.Response> getAllBookings() {
        return bookingRepository.findAll().stream()
            .map(BookingDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BookingDTO.Response> getMyBookings(Long userId) {
        User user = findUserOrThrow(userId);
        return bookingRepository.findByBookedByOrderByStartTimeDesc(user).stream()
            .map(BookingDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BookingDTO.Response> getUpcomingBookings(Long userId) {
        User user = findUserOrThrow(userId);
        return bookingRepository.findUpcomingBookingsByUser(user, LocalDateTime.now()).stream()
            .map(BookingDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BookingDTO.Response> getBookingsByRoom(Long roomId) throws ResourceNotFoundException {
        Room room = roomService.findRoomOrThrow(roomId);
        return bookingRepository.findByRoomOrderByStartTimeDesc(room).stream()
            .map(BookingDTO.Response::from).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public BookingDTO.Response getBookingById(Long id) {
        return BookingDTO.Response.from(findBookingOrThrow(id));
    }

    private Booking findBookingOrThrow(Long id) {
        try {
            return bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", id));
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private User findUserOrThrow(Long id) {
        try {
            return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
