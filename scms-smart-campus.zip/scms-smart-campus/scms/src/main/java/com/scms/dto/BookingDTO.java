package com.scms.dto;

import com.scms.model.Booking;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class BookingDTO {

    @Getter @Setter
    public static class Request {
        @NotNull  private Long roomId;
        @NotBlank private String title;
        private String description;
        @NotNull  private LocalDateTime startTime;
        @NotNull  private LocalDateTime endTime;
        @Min(1)   private int attendeesCount;
    }

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id;
        private Long roomId;
        private String roomNumber;
        private String roomName;
        private Long userId;
        private String bookedByName;
        private String title;
        private String description;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private String status;
        private int attendeesCount;
        private LocalDateTime createdAt;

        public static Response from(Booking booking) {
            return Response.builder()
                .id(booking.getId())
                .roomId(booking.getRoom().getId())
                .roomNumber(booking.getRoom().getRoomNumber())
                .roomName(booking.getRoom().getName())
                .userId(booking.getBookedBy().getId())
                .bookedByName(booking.getBookedBy().getFullName())
                .title(booking.getTitle())
                .description(booking.getDescription())
                .startTime(booking.getStartTime())
                .endTime(booking.getEndTime())
                .status(booking.getStatus().name())
                .attendeesCount(booking.getAttendeesCount())
                .createdAt(booking.getCreatedAt())
                .build();
        }
    }

    @Getter @Setter
    public static class CancelRequest {
        @NotBlank private String reason;
    }
}
