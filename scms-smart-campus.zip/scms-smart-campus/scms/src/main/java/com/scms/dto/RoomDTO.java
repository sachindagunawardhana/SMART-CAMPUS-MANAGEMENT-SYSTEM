package com.scms.dto;

import com.scms.model.Room;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class RoomDTO {

    @Getter @Setter
    public static class Request {
        @NotBlank private String roomNumber;
        @NotBlank private String name;
        @NotNull  private Room.RoomType type;
        @Min(1)   private int capacity;
        private String building;
        private String floor;
        private String description;
        private boolean hasProjector;
        private boolean hasWhiteboard;
        private boolean hasAC;
    }

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private Long id;
        private String roomNumber;
        private String name;
        private String type;
        private int capacity;
        private String building;
        private String floor;
        private String description;
        private String status;
        private boolean hasProjector;
        private boolean hasWhiteboard;
        private boolean hasAC;
        private LocalDateTime createdAt;

        public static Response from(Room room) {
            return Response.builder()
                .id(room.getId())
                .roomNumber(room.getRoomNumber())
                .name(room.getName())
                .type(room.getType().name())
                .capacity(room.getCapacity())
                .building(room.getBuilding())
                .floor(room.getFloor())
                .description(room.getDescription())
                .status(room.getStatus().name())
                .hasProjector(room.isHasProjector())
                .hasWhiteboard(room.isHasWhiteboard())
                .hasAC(room.isHasAC())
                .createdAt(room.getCreatedAt())
                .build();
        }
    }
}
