package com.scms.service.impl;

import com.scms.dto.RoomDTO;
import com.scms.model.Room;

/**
 * FACTORY PATTERN (Creational)
 *
 * Why: Centralises Room object creation. Allows pre-configuration
 * of rooms based on their type without scattering construction
 * logic across controllers or services.
 */
public class RoomFactory {

    private RoomFactory() {} // Prevent instantiation

    /**
     * Creates a Room with sensible defaults based on type.
     */
    public static Room createRoom(RoomDTO.Request request) {
        Room room = Room.builder()
            .roomNumber(request.getRoomNumber())
            .name(request.getName())
            .type(request.getType())
            .capacity(request.getCapacity())
            .building(request.getBuilding())
            .floor(request.getFloor())
            .description(request.getDescription())
            .hasProjector(request.isHasProjector())
            .hasWhiteboard(request.isHasWhiteboard())
            .hasAC(request.isHasAC())
            .status(Room.RoomStatus.AVAILABLE)
            .build();

        // Apply type-specific defaults
        switch (request.getType()) {
            case LECTURE_HALL -> {
                if (!request.isHasProjector()) room.setHasProjector(true);
                if (!request.isHasWhiteboard()) room.setHasWhiteboard(true);
            }
            case LAB -> {
                if (!request.isHasAC()) room.setHasAC(true);
            }
            case AUDITORIUM -> {
                if (!request.isHasProjector()) room.setHasProjector(true);
                if (!request.isHasAC()) room.setHasAC(true);
            }
            default -> { /* no defaults */ }
        }
        return room;
    }
}
