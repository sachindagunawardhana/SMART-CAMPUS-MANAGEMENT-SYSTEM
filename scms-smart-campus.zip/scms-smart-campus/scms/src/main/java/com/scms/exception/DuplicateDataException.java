package com.scms.exception;

import jakarta.transaction.SystemException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class DuplicateDataException extends SystemException {
    public DuplicateDataException(String message) {
        super(message + " | DUPLICATE_DATA");
    }

    public String getErrorCode() {
        return null;
    }
}
