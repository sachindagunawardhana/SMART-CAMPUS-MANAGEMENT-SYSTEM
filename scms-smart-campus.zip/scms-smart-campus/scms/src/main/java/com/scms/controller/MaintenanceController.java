package com.scms.controller;

import com.scms.dto.MaintenanceDTO;
import com.scms.exception.ResourceNotFoundException;
import com.scms.service.impl.MaintenanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/maintenance")
@RequiredArgsConstructor
public class MaintenanceController {

    private final MaintenanceService maintenanceService;

    @PostMapping
    public ResponseEntity<MaintenanceDTO.Response> createRequest(
            @Valid @RequestBody MaintenanceDTO.Request request,
            Authentication auth) throws ResourceNotFoundException {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(maintenanceService.createRequest(userId, request));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<MaintenanceDTO.Response>> getAllRequests() {
        return ResponseEntity.ok(maintenanceService.getAllRequests());
    }

    @GetMapping("/active")
    public ResponseEntity<List<MaintenanceDTO.Response>> getActiveRequests() {
        return ResponseEntity.ok(maintenanceService.getActiveRequests());
    }

    @GetMapping("/my")
    public ResponseEntity<List<MaintenanceDTO.Response>> getMyRequests(Authentication auth) throws ResourceNotFoundException {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.ok(maintenanceService.getMyRequests(userId));
    }

    @GetMapping("/assigned")
    @PreAuthorize("hasAnyRole('ADMIN','STAFF')")
    public ResponseEntity<List<MaintenanceDTO.Response>> getAssignedToMe(Authentication auth) throws ResourceNotFoundException {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.ok(maintenanceService.getAssignedToMe(userId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<MaintenanceDTO.Response> getById(@PathVariable Long id) throws ResourceNotFoundException {
        return ResponseEntity.ok(maintenanceService.getById(id));
    }

    @PatchMapping("/{id}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<MaintenanceDTO.Response> assignRequest(
            @PathVariable Long id,
            @Valid @RequestBody MaintenanceDTO.AssignRequest request,
            Authentication auth) throws Throwable {
        Long adminId = (Long) auth.getDetails();
        return ResponseEntity.ok(maintenanceService.assignRequest(id, adminId, request));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<MaintenanceDTO.Response> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody MaintenanceDTO.UpdateStatusRequest request,
            Authentication auth) throws Throwable {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.ok(maintenanceService.updateStatus(id, userId, request));
    }
}
