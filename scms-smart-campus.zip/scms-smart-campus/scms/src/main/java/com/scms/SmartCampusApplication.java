package com.scms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Smart Campus Management System - Main Entry Point
 * Architecture: Layered (Controller → Service → Repository)
 * Patterns: Factory, Facade, Observer
 */
@SpringBootApplication
public class SmartCampusApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartCampusApplication.class, args);
    }
}
