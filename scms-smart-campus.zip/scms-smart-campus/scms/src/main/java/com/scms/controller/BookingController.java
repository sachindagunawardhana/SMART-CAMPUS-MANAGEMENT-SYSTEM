package com.scms.controller;

import com.scms.dto.BookingDTO;
import com.scms.exception.ResourceNotFoundException;
import com.scms.service.impl.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ResponseEntity<BookingDTO.Response> createBooking(
            @Valid @RequestBody BookingDTO.Request request,
            Authentication auth) throws Throwable {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(bookingService.createBooking(userId, request));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<BookingDTO.Response>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    @GetMapping("/my")
    public ResponseEntity<List<BookingDTO.Response>> getMyBookings(Authentication auth) {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.ok(bookingService.getMyBookings(userId));
    }

    @GetMapping("/upcoming")
    public ResponseEntity<List<BookingDTO.Response>> getUpcomingBookings(Authentication auth) {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.ok(bookingService.getUpcomingBookings(userId));
    }

    @GetMapping("/room/{roomId}")
    public ResponseEntity<List<BookingDTO.Response>> getBookingsByRoom(@PathVariable Long roomId) throws ResourceNotFoundException {
        return ResponseEntity.ok(bookingService.getBookingsByRoom(roomId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookingDTO.Response> getBookingById(@PathVariable Long id) {
        return ResponseEntity.ok(bookingService.getBookingById(id));
    }

    @DeleteMapping("/{id}/cancel")
    public ResponseEntity<BookingDTO.Response> cancelBooking(
            @PathVariable Long id,
            @Valid @RequestBody BookingDTO.CancelRequest request,
            Authentication auth) throws Throwable {
        Long userId = (Long) auth.getDetails();
        return ResponseEntity.ok(bookingService.cancelBooking(id, userId, request.getReason()));
    }
}
