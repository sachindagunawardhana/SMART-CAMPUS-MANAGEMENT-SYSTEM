package com.scms.service.impl;

import com.scms.dto.AuthDTO;
import com.scms.exception.*;
import com.scms.model.User;
import com.scms.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public User register(AuthDTO.RegisterRequest request) throws DuplicateDataException {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateDataException("Username already taken: " + request.getUsername());
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateDataException("Email already registered: " + request.getEmail());
        }

        User user = buildUser(request);
        User saved = userRepository.save(user);
        log.info("User registered: {} ({})", saved.getUsername(), saved.getRole());
        return saved;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getAllUsers() {
        return userRepository.findAll().stream()
            .map(this::toMap)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getUsersByRole(User.Role role) {
        return userRepository.findByRole(role).stream()
            .map(this::toMap)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public User findByUsername(String username) {
        try {
            return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Transactional(readOnly = true)
    public User findById(Long id) throws ResourceNotFoundException {
        return userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }

    public void deactivateUser(Long id) throws ResourceNotFoundException {
        User user = findById(id);
        user.setActive(false);
        userRepository.save(user);
    }

    public void activateUser(Long id) throws ResourceNotFoundException {
        User user = findById(id);
        user.setActive(true);
        userRepository.save(user);
    }

    // ─── Helpers ─────────────────────────────────────────

    private User buildUser(AuthDTO.RegisterRequest req) {
        // Using a single concrete subtype stored in SINGLE_TABLE
        // We'll use a generic approach with discriminator set via role
        UserImpl user = new UserImpl();
        user.setUsername(req.getUsername());
        user.setPassword(passwordEncoder.encode(req.getPassword()));
        user.setFullName(req.getFullName());
        user.setEmail(req.getEmail());
        user.setRole(req.getRole());
        return user;
    }

    private Map<String, Object> toMap(User u) {
        return Map.of(
            "id", u.getId(),
            "username", u.getUsername(),
            "fullName", u.getFullName(),
            "email", u.getEmail(),
            "role", u.getRole().name(),
            "active", u.isActive()
        );
    }

    /**
     * Concrete User implementation used internally.
     * The abstract User is mapped via SINGLE_TABLE inheritance.
     */
    @jakarta.persistence.Entity
    @jakarta.persistence.DiscriminatorValue("USER")
    static class UserImpl extends User {
        @Override
        public String getDashboardTitle() {
            return switch (getRole()) {
                case ADMIN   -> "Administrator Control Panel";
                case STAFF   -> "Staff Member Portal";
                case STUDENT -> "Student Campus Portal";
            };
        }
    }
}
