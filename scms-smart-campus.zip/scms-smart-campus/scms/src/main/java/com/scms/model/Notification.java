package com.scms.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Notification entity — stores messages for users.
 * Part of the Observer pattern implementation.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "notifications")
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recipient_id", nullable = false)
    private User recipient;

    @Column(nullable = false)
    private String title;

    @Column(length = 500, nullable = false)
    private String message;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NotificationType type;

    @Column(nullable = false)
    private boolean read = false;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime readAt;

    // Reference to the source entity
    private String referenceType;  // "BOOKING", "MAINTENANCE"
    private Long referenceId;

    public enum NotificationType {
        BOOKING_CONFIRMED,
        BOOKING_CANCELLED,
        MAINTENANCE_SUBMITTED,
        MAINTENANCE_ASSIGNED,
        MAINTENANCE_UPDATED,
        MAINTENANCE_RESOLVED,
        GENERAL
    }
}
