package com.scms;

import com.scms.dto.BookingDTO;
import com.scms.dto.MaintenanceDTO;
import com.scms.dto.RoomDTO;
import com.scms.exception.DuplicateDataException;
import com.scms.exception.InvalidBookingException;
import com.scms.exception.ResourceNotFoundException;
import com.scms.exception.UnauthorizedAccessException;
import com.scms.model.*;
import com.scms.repository.*;
import com.scms.service.impl.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * ══════════════════════════════════════════════════════════
 * SCMS Unit Tests — JUnit 5 + Mockito
 * <p>
 * Test Coverage:
 *  1. Booking creation — happy path
 *  2. Double booking prevention
 *  3. Past-time booking rejection
 *  4. Capacity exceeded rejection
 *  5. Booking cancellation — unauthorised user
 *  6. Room creation — duplicate room number
 *  7. Maintenance request creation
 *  8. Maintenance assign — non-admin rejection
 *  9. Notification observer fires on booking
 * 10. INTENTIONALLY FAILING: wrong status assertion (demonstrates failing test)
 * ══════════════════════════════════════════════════════════
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("Smart Campus Management System — Unit Tests")
class ScmsUnitTests {

    // ─── Shared mocks ─────────────────────────────────────
    @Mock BookingRepository     bookingRepo;
    @Mock RoomRepository        roomRepo;
    @Mock UserRepository        userRepo;
    @Mock MaintenanceRequestRepository maintRepo;
    @Mock NotificationRepository notifRepo;

    @InjectMocks NotificationService notificationService;

    BookingService     bookingService;
    RoomService        roomService;
    MaintenanceService maintenanceService;

    // ─── Test fixtures ────────────────────────────────────
    User  adminUser, staffUser, studentUser;
    Room  availableRoom, maintRoom;
    final LocalDateTime FUTURE_START = LocalDateTime.now().plusDays(1).withHour(10).withMinute(0).withSecond(0);
    final LocalDateTime FUTURE_END   = LocalDateTime.now().plusDays(1).withHour(12).withMinute(0).withSecond(0);

    @BeforeEach
    void setup() {
        roomService        = new RoomService(roomRepo);
        notificationService = new NotificationService(notifRepo, userRepo);
        bookingService     = new BookingService(bookingRepo, userRepo, roomService, notificationService);
        maintenanceService = new MaintenanceService(maintRepo, userRepo, roomService, notificationService);

        adminUser = buildUser(1L, "admin",   User.Role.ADMIN);
        staffUser = buildUser(2L, "staff",   User.Role.STAFF);
        studentUser= buildUser(3L, "student", User.Role.STUDENT);

        availableRoom = Room.builder()
            .id(10L).roomNumber("LH-101").name("Main Hall")
            .type(Room.RoomType.LECTURE_HALL).capacity(100)
            .status(Room.RoomStatus.AVAILABLE).build();

        maintRoom = Room.builder()
            .id(11L).roomNumber("SR-201").name("Seminar A")
            .type(Room.RoomType.SEMINAR_ROOM).capacity(30)
            .status(Room.RoomStatus.UNDER_MAINTENANCE).build();
    }

    // ══════════════════════════════════════════════════════
    // TEST 1: Successful booking creation
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC01 — Should create a booking successfully")
    void testCreateBooking_Success() {
        // Arrange
        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser));
        when(roomRepo.findById(10L)).thenReturn(Optional.of(availableRoom));
        when(bookingRepo.findConflictingBookings(any(), any(), any())).thenReturn(Collections.emptyList());

        Booking savedBooking = Booking.builder()
            .id(100L).room(availableRoom).bookedBy(studentUser)
            .title("CS Study Session").startTime(FUTURE_START).endTime(FUTURE_END)
            .attendeesCount(5).status(Booking.BookingStatus.CONFIRMED).build();
        when(bookingRepo.save(any())).thenReturn(savedBooking);
        when(notifRepo.save(any())).thenReturn(new Notification());

        BookingDTO.Request req = new BookingDTO.Request();
        req.setRoomId(10L); req.setTitle("CS Study Session");
        req.setStartTime(FUTURE_START); req.setEndTime(FUTURE_END);
        req.setAttendeesCount(5);

        // Act
        BookingDTO.Response resp;
        try {
            resp = bookingService.createBooking(3L, req);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }

        // Assert
        assertNotNull(resp);
        assertEquals(100L, resp.getId());
        assertEquals("CONFIRMED", resp.getStatus());
        verify(bookingRepo).save(any(Booking.class));
    }

    // ══════════════════════════════════════════════════════
    // TEST 2: Double booking prevention
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC02 — Should prevent double booking for same time slot")
    void testCreateBooking_DoubleBookingPrevented() {
        // Arrange: an existing booking occupies the slot
        Booking existing = Booking.builder()
            .id(99L).room(availableRoom).status(Booking.BookingStatus.CONFIRMED)
            .startTime(FUTURE_START).endTime(FUTURE_END).build();

        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser));
        when(roomRepo.findById(10L)).thenReturn(Optional.of(availableRoom));
        when(bookingRepo.findConflictingBookings(any(), any(), any()))
            .thenReturn(List.of(existing));

        BookingDTO.Request req = new BookingDTO.Request();
        req.setRoomId(10L); req.setTitle("Another Session");
        req.setStartTime(FUTURE_START); req.setEndTime(FUTURE_END);
        req.setAttendeesCount(10);

        // Act & Assert
        InvalidBookingException ex = assertThrows(
            InvalidBookingException.class,
            () -> bookingService.createBooking(3L, req)
        );
        assertTrue(ex.getMessage().contains("already booked"));
        verify(bookingRepo, never()).save(any());
    }

    // ══════════════════════════════════════════════════════
    // TEST 3: Pastime booking rejected
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC03 — Should reject booking in the past")
    void testCreateBooking_PastTimeRejected() {
        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser));
        when(roomRepo.findById(10L)).thenReturn(Optional.of(availableRoom));

        BookingDTO.Request req = new BookingDTO.Request();
        req.setRoomId(10L); req.setTitle("Past Event");
        req.setStartTime(LocalDateTime.now().minusDays(1));
        req.setEndTime(LocalDateTime.now().minusHours(22));
        req.setAttendeesCount(5);

        InvalidBookingException ex = assertThrows(
            InvalidBookingException.class,
            () -> bookingService.createBooking(3L, req)
        );
        assertTrue(ex.getMessage().contains("past"));
    }

    // ══════════════════════════════════════════════════════
    // TEST 4: Capacity exceeded
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC04 — Should reject booking when attendees exceed capacity")
    void testCreateBooking_CapacityExceeded() {
        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser));
        when(roomRepo.findById(10L)).thenReturn(Optional.of(availableRoom)); // capacity = 100

        BookingDTO.Request req = new BookingDTO.Request();
        req.setRoomId(10L); req.setTitle("Overflow Event");
        req.setStartTime(FUTURE_START); req.setEndTime(FUTURE_END);
        req.setAttendeesCount(999); // exceeds 100

        InvalidBookingException ex = assertThrows(
            InvalidBookingException.class,
            () -> bookingService.createBooking(3L, req)
        );
        assertTrue(ex.getMessage().contains("exceed room capacity"));
    }

    // ══════════════════════════════════════════════════════
    // TEST 5: Unauthorised cancellation
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC05 — Should reject cancellation by non-owner non-admin")
    void testCancelBooking_Unauthorised() {
        // Booking owned by student (id=3), attempted cancel by different user (id=99)
        User otherUser = buildUser(99L, "other", User.Role.STUDENT);
        Booking booking = Booking.builder()
            .id(100L).room(availableRoom).bookedBy(studentUser)
            .status(Booking.BookingStatus.CONFIRMED)
            .startTime(FUTURE_START).endTime(FUTURE_END).build();

        when(bookingRepo.findById(100L)).thenReturn(Optional.of(booking));
        when(userRepo.findById(99L)).thenReturn(Optional.of(otherUser));

        assertThrows(
            UnauthorizedAccessException.class,
            () -> bookingService.cancelBooking(100L, 99L, "No reason")
        );
        verify(bookingRepo, never()).save(any());
    }

    // ══════════════════════════════════════════════════════
    // TEST 6: Duplicate room number
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC06 — Should prevent duplicate room number")
    void testCreateRoom_DuplicateNumber() {
        when(roomRepo.existsByRoomNumber("LH-101")).thenReturn(true);

        RoomDTO.Request req = new RoomDTO.Request();
        req.setRoomNumber("LH-101"); req.setName("Another Hall");
        req.setType(Room.RoomType.LECTURE_HALL); req.setCapacity(50);

        DuplicateDataException ex = assertThrows(
            DuplicateDataException.class,
            () -> roomService.createRoom(req)
        );
        assertTrue(ex.getMessage().contains("LH-101"));
        verify(roomRepo, never()).save(any());
    }

    // ══════════════════════════════════════════════════════
    // TEST 7: Maintenance request creation
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC07 — Should create maintenance request successfully")
    void testCreateMaintenance_Success() {
        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser));
        when(roomRepo.findById(10L)).thenReturn(Optional.of(availableRoom));
        when(userRepo.findByRole(User.Role.ADMIN)).thenReturn(List.of(adminUser));

        MaintenanceRequest saved = MaintenanceRequest.builder()
            .id(50L).room(availableRoom).reportedBy(studentUser)
            .title("AC not working").description("Cold").priority(MaintenanceRequest.Priority.HIGH)
            .status(MaintenanceRequest.RequestStatus.OPEN).build();
        when(maintRepo.save(any())).thenReturn(saved);
        when(notifRepo.save(any())).thenReturn(new Notification());

        MaintenanceDTO.Request req = new MaintenanceDTO.Request();
        req.setRoomId(10L); req.setTitle("AC not working");
        req.setDescription("Cold"); req.setPriority(MaintenanceRequest.Priority.HIGH);

        MaintenanceDTO.Response resp;
        try {
            resp = maintenanceService.createRequest(3L, req);
        } catch (ResourceNotFoundException e) {
            throw new RuntimeException(e);
        }

        assertNotNull(resp);
        assertEquals(50L, resp.getId());
        assertEquals("OPEN", resp.getStatus());
        assertEquals("HIGH", resp.getPriority());
    }

    // ══════════════════════════════════════════════════════
    // TEST 8: Assign maintenance — non-admin rejected
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC08 — Should reject maintenance assignment by non-admin")
    void testAssignMaintenance_NonAdminRejected() {
        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser)); // student, not admin

        MaintenanceDTO.AssignRequest req = new MaintenanceDTO.AssignRequest();
        req.setStaffId(2L);

        assertThrows(
            UnauthorizedAccessException.class,
            () -> maintenanceService.assignRequest(50L, 3L, req)
        );
        verify(maintRepo, never()).save(any());
    }

    // ══════════════════════════════════════════════════════
    // TEST 9: Notification fired on booking
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("✅ TC09 — Should fire notification on booking creation")
    void testNotificationFiredOnBooking() {
        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser));
        when(roomRepo.findById(10L)).thenReturn(Optional.of(availableRoom));
        when(bookingRepo.findConflictingBookings(any(), any(), any())).thenReturn(Collections.emptyList());

        Booking saved = Booking.builder()
            .id(100L).room(availableRoom).bookedBy(studentUser)
            .title("Test").startTime(FUTURE_START).endTime(FUTURE_END)
            .attendeesCount(1).status(Booking.BookingStatus.CONFIRMED).build();
        when(bookingRepo.save(any())).thenReturn(saved);
        when(notifRepo.save(any())).thenReturn(new Notification());

        BookingDTO.Request req = new BookingDTO.Request();
        req.setRoomId(10L); req.setTitle("Test");
        req.setStartTime(FUTURE_START); req.setEndTime(FUTURE_END);
        req.setAttendeesCount(1);

        try {
            bookingService.createBooking(3L, req);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }

        // Notification must be persisted at least once
        verify(notifRepo, atLeastOnce()).save(any(Notification.class));
    }

    // ══════════════════════════════════════════════════════
    // TEST 10: INTENTIONALLY FAILING TEST
    // This test deliberately asserts an incorrect expected value
    // to demonstrate what a failing test looks like.
    // Expected: "CONFIRMED" — Incorrect assertion: "CANCELLED"
    // ══════════════════════════════════════════════════════
    @Test
    @DisplayName("❌ TC10 — [INTENTIONAL FAIL] Wrong status assertion demo")
    void testIntentionallyFailing_WrongStatusAssertion() {
        when(userRepo.findById(3L)).thenReturn(Optional.of(studentUser));
        when(roomRepo.findById(10L)).thenReturn(Optional.of(availableRoom));
        when(bookingRepo.findConflictingBookings(any(), any(), any())).thenReturn(Collections.emptyList());

        Booking saved = Booking.builder()
            .id(200L).room(availableRoom).bookedBy(studentUser)
            .title("Failing Test Booking").startTime(FUTURE_START).endTime(FUTURE_END)
            .attendeesCount(2).status(Booking.BookingStatus.CONFIRMED).build();
        when(bookingRepo.save(any())).thenReturn(saved);
        when(notifRepo.save(any())).thenReturn(new Notification());

        BookingDTO.Request req = new BookingDTO.Request();
        req.setRoomId(10L); req.setTitle("Failing Test Booking");
        req.setStartTime(FUTURE_START); req.setEndTime(FUTURE_END);
        req.setAttendeesCount(2);

        BookingDTO.Response resp;
        try {
            resp = bookingService.createBooking(3L, req);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }

        // INTENTIONAL FAIL: booking is CONFIRMED but we assert CANCELLED
        assertEquals("CANCELLED", resp.getStatus(),
            "INTENTIONAL FAIL — This test is designed to fail. " +
            "Actual status is CONFIRMED, not CANCELLED.");
    }

    // ─── Helpers ─────────────────────────────────────────
    private User buildUser(Long id, String username, User.Role role) {
        // Use a simple anonymous subclass for testing
        User u = new User() {
            @Override public String getDashboardTitle() { return "Test"; }
        };
        u.setId(id);
        u.setUsername(username);
        u.setFullName(username + " Name");
        u.setEmail(username + "@test.com");
        u.setPassword("encoded");
        u.setRole(role);
        u.setActive(true);
        return u;
    }
}
