/* ============================================================
   SCMS — Shared JavaScript utilities + API client
   ============================================================ */

const API_BASE = 'http://localhost:8080/api';

/* ── Token management ────────────────────────────────────── */
const Auth = {
  getToken:    () => localStorage.getItem('scms_token'),
  getUser:     () => JSON.parse(localStorage.getItem('scms_user') || 'null'),
  setSession:  (token, user) => {
    localStorage.setItem('scms_token', token);
    localStorage.setItem('scms_user', JSON.stringify(user));
  },
  clearSession: () => {
    localStorage.removeItem('scms_token');
    localStorage.removeItem('scms_user');
  },
  isLoggedIn:  () => !!localStorage.getItem('scms_token'),
  hasRole:     (role) => Auth.getUser()?.role === role,
  isAdmin:     () => Auth.hasRole('ADMIN'),
  isStaff:     () => Auth.hasRole('STAFF'),
  isStudent:   () => Auth.hasRole('STUDENT'),
};

/* ── HTTP client ─────────────────────────────────────────── */
const Http = {
  async request(method, endpoint, body = null, auth = true) {
    const headers = { 'Content-Type': 'application/json' };
    if (auth) {
      const token = Auth.getToken();
      if (token) headers['Authorization'] = `Bearer ${token}`;
    }
    const opts = { method, headers };
    if (body) opts.body = JSON.stringify(body);

    const res = await fetch(`${API_BASE}${endpoint}`, opts);
    const data = res.headers.get('Content-Type')?.includes('application/json')
      ? await res.json() : await res.text();

    if (!res.ok) {
      const msg = data?.message || data?.error || `HTTP ${res.status}`;
      throw { status: res.status, message: msg, data };
    }
    return data;
  },
  get:    (ep) => Http.request('GET', ep),
  post:   (ep, body, auth=true) => Http.request('POST', ep, body, auth),
  put:    (ep, body) => Http.request('PUT', ep, body),
  delete: (ep) => Http.request('DELETE', ep),
};

/* ── Toast notifications ─────────────────────────────────── */
const Toast = {
  container: null,
  init() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  },
  show(type, title, msg, duration = 4000) {
    this.init();
    const icons = { success: '✓', error: '✕', warn: '⚠', info: 'ℹ' };
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `
      <div class="toast-icon">${icons[type] || 'ℹ'}</div>
      <div class="toast-text">
        <div class="toast-title">${title}</div>
        ${msg ? `<div class="toast-msg">${msg}</div>` : ''}
      </div>
    `;
    this.container.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateX(20px)';
      el.style.transition = 'all 0.3s ease';
      setTimeout(() => el.remove(), 300);
    }, duration);
  },
  success: (title, msg) => Toast.show('success', title, msg),
  error:   (title, msg) => Toast.show('error', title, msg),
  warn:    (title, msg) => Toast.show('warn', title, msg),
  info:    (title, msg) => Toast.show('info', title, msg),
};

/* ── Modal helpers ───────────────────────────────────────── */
const Modal = {
  show(id) { document.getElementById(id)?.classList.remove('hidden'); },
  hide(id) { document.getElementById(id)?.classList.add('hidden'); },
  showEl(el) { el?.classList.remove('hidden'); },
  hideEl(el) { el?.classList.add('hidden'); },
};

/* ── Formatting helpers ───────────────────────────────────── */
const Fmt = {
  date(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
  },
  datetime(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleString('en-US', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  },
  badge(val) {
    if (!val) return '';
    const lower = val.toLowerCase().replace('_', '-');
    return `<span class="badge badge-${lower}">${val.replace('_', ' ')}</span>`;
  },
  initials(name) {
    return name?.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) || 'U';
  },
  relativeTime(iso) {
    if (!iso) return '';
    const diff = Date.now() - new Date(iso).getTime();
    const mins  = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days  = Math.floor(diff / 86400000);
    if (mins < 1)   return 'just now';
    if (mins < 60)  return `${mins}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  }
};

/* ── DOM helpers ─────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
const el = (html) => { const d = document.createElement('div'); d.innerHTML = html; return d.firstChild; };

/* ── Navigation guard ────────────────────────────────────── */
function requireAuth() {
  if (!Auth.isLoggedIn()) {
    window.location.href = 'login.html';
    return false;
  }
  return true;
}

function redirectIfLoggedIn() {
  if (Auth.isLoggedIn()) {
    window.location.href = 'dashboard.html';
  }
}

/* ── Sidebar bootstrap ───────────────────────────────────── */
function initSidebar(activePage) {
  const user = Auth.getUser();
  if (!user) return;

  // Set user info
  const el_avatar = document.getElementById('sidebar-avatar');
  const el_name   = document.getElementById('sidebar-name');
  const el_role   = document.getElementById('sidebar-role');
  if (el_avatar) el_avatar.textContent = Fmt.initials(user.fullName);
  if (el_name)   el_name.textContent   = user.fullName;
  if (el_role)   el_role.textContent   = user.role;

  // Mark active nav link
  $$('.nav-link').forEach(link => {
    if (link.dataset.page === activePage) link.classList.add('active');
  });

  // Admin-only nav items
  if (!Auth.isAdmin()) {
    $$('.admin-only').forEach(el => el.classList.add('hidden'));
  }
  if (Auth.isStudent()) {
    $$('.staff-only').forEach(el => el.classList.add('hidden'));
  }

  // Logout
  document.getElementById('btn-logout')?.addEventListener('click', () => {
    Auth.clearSession();
    window.location.href = 'login.html';
  });

  // Load unread notification count
  loadUnreadCount();

  // Topbar clock
  const clock = document.getElementById('topbar-time');
  if (clock) {
    const tick = () => { clock.textContent = new Date().toLocaleTimeString(); };
    tick(); setInterval(tick, 1000);
  }
}

async function loadUnreadCount() {
  try {
    const count = await Http.get('/notifications/unread/count');
    const badge = document.getElementById('notif-badge');
    if (badge) {
      badge.textContent = count;
      badge.classList.toggle('hidden', count === 0);
    }
  } catch(e) { /* ignore */ }
}

/* ── Table builder ───────────────────────────────────────── */
function buildTable(container, columns, rows, emptyMsg = 'No data found.') {
  if (!rows || rows.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
      <p>${emptyMsg}</p>
    </div>`;
    return;
  }
  const ths = columns.map(c => `<th>${c.label}</th>`).join('');
  const trs = rows.map(row => {
    const tds = columns.map(c => {
      const val = typeof c.render === 'function' ? c.render(row) : (row[c.key] ?? '—');
      return `<td>${val}</td>`;
    }).join('');
    return `<tr>${tds}</tr>`;
  }).join('');
  container.innerHTML = `<div class="table-wrap"><table><thead><tr>${ths}</tr></thead><tbody>${trs}</tbody></table></div>`;
}

/* ── Input validation helpers ────────────────────────────── */
function showFieldError(inputId, msg) {
  const el = document.getElementById(inputId);
  if (!el) return;
  el.style.borderColor = 'var(--danger)';
  let hint = el.parentNode.querySelector('.form-error');
  if (!hint) { hint = document.createElement('span'); hint.className = 'form-error'; el.parentNode.appendChild(hint); }
  hint.textContent = msg;
}
function clearFieldErrors(formId) {
  $$(`#${formId} .form-control`).forEach(el => { el.style.borderColor = ''; });
  $$(`#${formId} .form-error`).forEach(el => el.remove());
}
