package com.scms.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class NotificationDto {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {
        private Long id;
        private String title;
        private String message;
        private String type;
        private boolean read;
        private Long referenceId;
        private String referenceType;
        private LocalDateTime createdAt;
        private LocalDateTime readAt;
    }
}
