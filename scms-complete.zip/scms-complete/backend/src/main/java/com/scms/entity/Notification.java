package com.scms.entity;

import com.scms.enums.NotificationType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * Notification entity — part of the Observer pattern.
 * Created whenever a significant event occurs in the system.
 */
@Entity
@Table(name = "notifications",
    indexes = {
        @Index(name = "idx_recipient_read", columnList = "recipient_id,is_read")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, length = 500)
    private String message;

    @Enumerated(EnumType.STRING)
    @Column(name = "notification_type", nullable = false)
    private NotificationType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recipient_id", nullable = false)
    private User recipient;

    @Column(name = "is_read")
    private boolean read = false;

    @Column(name = "reference_id")
    private Long referenceId;  // e.g., bookingId or maintenanceRequestId

    @Column(name = "reference_type")
    private String referenceType; // e.g., "BOOKING", "MAINTENANCE"

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "read_at")
    private LocalDateTime readAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    /**
     * Marks the notification as read.
     */
    public void markAsRead() {
        this.read = true;
        this.readAt = LocalDateTime.now();
    }
}
