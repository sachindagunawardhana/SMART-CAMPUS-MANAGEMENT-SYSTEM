package com.scms.controller;

import com.scms.dto.AuthDto;
import com.scms.entity.User;
import com.scms.security.JwtUtils;
import com.scms.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

/**
 * Handles user registration and login.
 * Public endpoints — no JWT required.
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtils              jwtUtils;
    private final UserService           userService;

    /**
     * POST /api/auth/login
     * Returns a JWT token on successful authentication.
     */
    @PostMapping("/login")
    public ResponseEntity<AuthDto.LoginResponse> login(
            @Valid @RequestBody AuthDto.LoginRequest request) {

        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(), request.getPassword()));

        String token = jwtUtils.generateToken(auth);
        User user    = userService.getUserByEmail(request.getEmail());

        return ResponseEntity.ok(new AuthDto.LoginResponse(
                token, user.getId(), user.getEmail(),
                user.getFullName(), user.getRole().name()));
    }

    /**
     * POST /api/auth/register
     * Registers a new user (Admin can register any role).
     */
    @PostMapping("/register")
    public ResponseEntity<String> register(
            @Valid @RequestBody AuthDto.RegisterRequest request) {

        User created = userService.registerUser(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("User registered successfully with id: " + created.getId());
    }
}
