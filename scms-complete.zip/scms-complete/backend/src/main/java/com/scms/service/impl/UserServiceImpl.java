package com.scms.service.impl;

import com.scms.dto.AuthDto;
import com.scms.entity.*;
import com.scms.enums.UserRole;
import com.scms.exception.DuplicateDataException;
import com.scms.exception.ResourceNotFoundException;
import com.scms.repository.UserRepository;
import com.scms.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Handles user registration and retrieval.
 *
 * Factory Pattern — createUserByRole() acts as a simple Factory Method,
 * returning the appropriate User subclass based on the requested role.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // ── Factory Method: creates the correct User subtype ──────────────────

    @Override
    public User registerUser(AuthDto.RegisterRequest req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new DuplicateDataException("email", req.getEmail());
        }

        UserRole role = UserRole.valueOf(req.getRole().toUpperCase());
        User user = createUserByRole(req, role);
        User saved = userRepository.save(user);
        log.info("Registered new user: {} [{}]", saved.getEmail(), saved.getRole());
        return saved;
    }

    /**
     * Factory Method — instantiates the correct User subclass.
     * Adding a new role only requires adding a new case here — Open/Closed Principle.
     */
    private User createUserByRole(AuthDto.RegisterRequest req, UserRole role) {
        String encodedPassword = passwordEncoder.encode(req.getPassword());

        return switch (role) {
            case ADMIN -> new Admin(
                    req.getFirstName(), req.getLastName(),
                    req.getEmail(), encodedPassword,
                    req.getDepartment());

            case STAFF -> new Staff(
                    req.getFirstName(), req.getLastName(),
                    req.getEmail(), encodedPassword,
                    req.getEmployeeId(), req.getDepartment(), req.getPosition());

            case STUDENT -> new Student(
                    req.getFirstName(), req.getLastName(),
                    req.getEmail(), encodedPassword,
                    req.getStudentId(), req.getFaculty(), req.getYearOfStudy());
        };
    }

    // ── Retrieval ──────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public User getCurrentUser() {
        String email = SecurityContextHolder.getContext()
                .getAuthentication().getName();
        return getUserByEmail(email);
    }

    @Override
    @Transactional(readOnly = true)
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
    }

    @Override
    @Transactional(readOnly = true)
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public void deactivateUser(Long userId) {
        User user = getUserById(userId);
        user.setActive(false);
        userRepository.save(user);
        log.info("Deactivated user: {}", user.getEmail());
    }
}
