package com.scms.entity;

import com.scms.enums.UserRole;
import jakarta.persistence.*;
import lombok.*;

/**
 * Admin user — full system access.
 * Can manage rooms, assign maintenance, and send announcements.
 */
@Entity
@DiscriminatorValue("ADMIN")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Admin extends User {

    @Column(name = "department")
    private String department;

    public Admin(String firstName, String lastName, String email,
                 String password, String department) {
        super(null, firstName, lastName, email, password,
              UserRole.ADMIN, true, null, null, null);
        this.department = department;
    }

    @Override
    public String getRoleDescription() {
        return "System Administrator - Full Access";
    }
}
