package com.scms.service;

import com.scms.dto.NotificationDto;
import com.scms.entity.User;
import com.scms.enums.NotificationType;

import java.util.List;

public interface NotificationService extends NotificationPublisher {

    /**
     * Persist and dispatch a notification to a single user.
     */
    void sendNotification(User recipient, String title, String message,
                          NotificationType type, Long referenceId, String referenceType);

    /**
     * Broadcast a notification to multiple users.
     */
    void broadcastNotification(List<User> recipients, String title, String message,
                               NotificationType type, Long referenceId, String referenceType);

    /**
     * Get all notifications for the currently authenticated user.
     */
    List<NotificationDto.Response> getMyNotifications();

    /**
     * Get only unread notifications for the current user.
     */
    List<NotificationDto.Response> getMyUnreadNotifications();

    /**
     * Mark a specific notification as read.
     */
    void markAsRead(Long notificationId);

    /**
     * Mark all of the current user's notifications as read.
     */
    void markAllAsRead();

    /**
     * Count of unread notifications for the current user.
     */
    long countUnread();
}
