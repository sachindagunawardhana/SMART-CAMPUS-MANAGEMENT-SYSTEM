package com.scms.entity;

import com.scms.enums.RoomType;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a campus room that can be booked.
 * Composition: Room contains a list of Bookings.
 */
@Entity
@Table(name = "rooms")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Room number is required")
    @Column(name = "room_number", unique = true, nullable = false)
    private String roomNumber;

    @NotBlank(message = "Room name is required")
    @Column(name = "room_name", nullable = false)
    private String roomName;

    @NotNull(message = "Room type is required")
    @Enumerated(EnumType.STRING)
    @Column(name = "room_type", nullable = false)
    private RoomType roomType;

    @Min(value = 1, message = "Capacity must be at least 1")
    @Column(nullable = false)
    private Integer capacity;

    @Column(name = "building")
    private String building;

    @Column(name = "floor_number")
    private Integer floorNumber;

    @Column(name = "has_projector")
    private boolean hasProjector;

    @Column(name = "has_whiteboard")
    private boolean hasWhiteboard;

    @Column(name = "has_air_conditioning")
    private boolean hasAirConditioning;

    @Column(name = "is_active")
    private boolean active = true;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "room", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Booking> bookings = new ArrayList<>();

    @OneToMany(mappedBy = "room", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<MaintenanceRequest> maintenanceRequests = new ArrayList<>();

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Deactivates the room — prevents future bookings.
     */
    public void deactivate() {
        this.active = false;
    }

    /**
     * Activates the room for bookings.
     */
    public void activate() {
        this.active = true;
    }
}
