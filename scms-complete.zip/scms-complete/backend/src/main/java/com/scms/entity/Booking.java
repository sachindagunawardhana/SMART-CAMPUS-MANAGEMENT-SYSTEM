package com.scms.entity;

import com.scms.enums.BookingStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

/**
 * Represents a room booking made by a user.
 * Composition: Booking belongs to a Room and a User.
 * Prevents double-booking via service-layer validation.
 */
@Entity
@Table(name = "bookings",
    indexes = {
        @Index(name = "idx_room_time", columnList = "room_id,start_time,end_time"),
        @Index(name = "idx_user_bookings", columnList = "user_id")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User bookedBy;

    @NotNull
    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @NotNull
    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    @Column(name = "purpose", length = 300)
    private String purpose;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private BookingStatus status;

    @Column(name = "attendees_count")
    private Integer attendeesCount;

    @Column(name = "cancellation_reason", length = 300)
    private String cancellationReason;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.status == null) {
            this.status = BookingStatus.PENDING;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Checks if this booking overlaps with the given time range.
     * Used for double-booking prevention.
     */
    public boolean overlapsWith(LocalDateTime start, LocalDateTime end) {
        return !this.endTime.isBefore(start) && !this.startTime.isAfter(end);
    }

    /**
     * Confirms the booking.
     */
    public void confirm() {
        this.status = BookingStatus.CONFIRMED;
    }

    /**
     * Cancels the booking with a reason.
     */
    public void cancel(String reason) {
        this.status = BookingStatus.CANCELLED;
        this.cancellationReason = reason;
    }

    /**
     * Marks the booking as completed.
     */
    public void complete() {
        this.status = BookingStatus.COMPLETED;
    }
}
