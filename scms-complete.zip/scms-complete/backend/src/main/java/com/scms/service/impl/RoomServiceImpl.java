package com.scms.service.impl;

import com.scms.dto.RoomDto;
import com.scms.entity.Room;
import com.scms.exception.DuplicateDataException;
import com.scms.exception.ResourceNotFoundException;
import com.scms.repository.RoomRepository;
import com.scms.service.RoomService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Room management — Admin-only mutations, read-access for all.
 *
 * Builder Pattern is used via Room.builder() for readable Room construction.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    // ── Create ─────────────────────────────────────────────────────────────

    @Override
    public RoomDto.Response createRoom(RoomDto.CreateRequest req) {
        if (roomRepository.existsByRoomNumber(req.getRoomNumber())) {
            throw new DuplicateDataException("roomNumber", req.getRoomNumber());
        }

        // Builder Pattern — clean, readable object construction
        Room room = Room.builder()
                .roomNumber(req.getRoomNumber())
                .roomName(req.getRoomName())
                .roomType(req.getRoomType())
                .capacity(req.getCapacity())
                .building(req.getBuilding())
                .floorNumber(req.getFloorNumber())
                .hasProjector(req.isHasProjector())
                .hasWhiteboard(req.isHasWhiteboard())
                .hasAirConditioning(req.isHasAirConditioning())
                .description(req.getDescription())
                .active(true)
                .build();

        Room saved = roomRepository.save(room);
        log.info("Room created: {} [{}]", saved.getRoomName(), saved.getRoomNumber());
        return toResponse(saved);
    }

    // ── Update ─────────────────────────────────────────────────────────────

    @Override
    public RoomDto.Response updateRoom(Long roomId, RoomDto.UpdateRequest req) {
        Room room = getRoomEntityById(roomId);

        if (req.getRoomName()          != null) room.setRoomName(req.getRoomName());
        if (req.getCapacity()          != null) room.setCapacity(req.getCapacity());
        if (req.getBuilding()          != null) room.setBuilding(req.getBuilding());
        if (req.getFloorNumber()       != null) room.setFloorNumber(req.getFloorNumber());
        if (req.getHasProjector()      != null) room.setHasProjector(req.getHasProjector());
        if (req.getHasWhiteboard()     != null) room.setHasWhiteboard(req.getHasWhiteboard());
        if (req.getHasAirConditioning()!= null) room.setHasAirConditioning(req.getHasAirConditioning());
        if (req.getDescription()       != null) room.setDescription(req.getDescription());

        Room updated = roomRepository.save(room);
        log.info("Room updated: {}", updated.getRoomNumber());
        return toResponse(updated);
    }

    // ── Status changes ─────────────────────────────────────────────────────

    @Override
    public void deactivateRoom(Long roomId) {
        Room room = getRoomEntityById(roomId);
        room.deactivate();
        roomRepository.save(room);
        log.info("Room deactivated: {}", room.getRoomNumber());
    }

    @Override
    public void activateRoom(Long roomId) {
        Room room = getRoomEntityById(roomId);
        room.activate();
        roomRepository.save(room);
        log.info("Room activated: {}", room.getRoomNumber());
    }

    // ── Read ───────────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public RoomDto.Response getRoomById(Long roomId) {
        return toResponse(getRoomEntityById(roomId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<RoomDto.Response> getAllRooms() {
        return roomRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<RoomDto.Response> getActiveRooms() {
        return roomRepository.findByActiveTrue().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<RoomDto.Response> getAvailableRooms(LocalDateTime startTime,
                                                     LocalDateTime endTime) {
        return roomRepository.findAvailableRooms(startTime, endTime).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<RoomDto.Response> getAvailableRoomsFiltered(RoomDto.AvailabilityRequest req) {
        List<Room> available = roomRepository.findAvailableRooms(req.getStartTime(), req.getEndTime());

        return available.stream()
                .filter(r -> req.getMinCapacity() == null || r.getCapacity() >= req.getMinCapacity())
                .filter(r -> req.getRoomType()    == null || r.getRoomType() == req.getRoomType())
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Room getRoomEntityById(Long roomId) {
        return roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room", "id", roomId));
    }

    // ── Mapper ─────────────────────────────────────────────────────────────

    private RoomDto.Response toResponse(Room r) {
        RoomDto.Response res = new RoomDto.Response();
        res.setId(r.getId());
        res.setRoomNumber(r.getRoomNumber());
        res.setRoomName(r.getRoomName());
        res.setRoomType(r.getRoomType().name());
        res.setCapacity(r.getCapacity());
        res.setBuilding(r.getBuilding());
        res.setFloorNumber(r.getFloorNumber());
        res.setHasProjector(r.isHasProjector());
        res.setHasWhiteboard(r.isHasWhiteboard());
        res.setHasAirConditioning(r.isHasAirConditioning());
        res.setActive(r.isActive());
        res.setDescription(r.getDescription());
        res.setCreatedAt(r.getCreatedAt());
        return res;
    }
}
