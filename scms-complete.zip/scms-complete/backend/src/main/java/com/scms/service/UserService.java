package com.scms.service;

import com.scms.dto.AuthDto;
import com.scms.entity.User;

import java.util.List;

public interface UserService {

    User registerUser(AuthDto.RegisterRequest request);

    User getCurrentUser();

    User getUserById(Long id);

    User getUserByEmail(String email);

    List<User> getAllUsers();

    void deactivateUser(Long userId);
}
