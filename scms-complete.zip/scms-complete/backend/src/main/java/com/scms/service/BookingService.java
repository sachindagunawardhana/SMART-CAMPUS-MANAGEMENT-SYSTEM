package com.scms.service;

import com.scms.dto.BookingDto;

import java.util.List;

public interface BookingService {

    BookingDto.Response createBooking(BookingDto.CreateRequest request);

    BookingDto.Response confirmBooking(Long bookingId);

    BookingDto.Response cancelBooking(Long bookingId, BookingDto.CancelRequest request);

    BookingDto.Response getBookingById(Long bookingId);

    List<BookingDto.Response> getMyBookings();

    List<BookingDto.Response> getAllBookings();

    List<BookingDto.Response> getBookingsByRoom(Long roomId);
}
