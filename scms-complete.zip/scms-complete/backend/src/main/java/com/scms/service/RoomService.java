package com.scms.service;

import com.scms.dto.RoomDto;
import com.scms.entity.Room;

import java.time.LocalDateTime;
import java.util.List;

public interface RoomService {

    RoomDto.Response createRoom(RoomDto.CreateRequest request);

    RoomDto.Response updateRoom(Long roomId, RoomDto.UpdateRequest request);

    void deactivateRoom(Long roomId);

    void activateRoom(Long roomId);

    RoomDto.Response getRoomById(Long roomId);

    List<RoomDto.Response> getAllRooms();

    List<RoomDto.Response> getActiveRooms();

    List<RoomDto.Response> getAvailableRooms(LocalDateTime startTime, LocalDateTime endTime);

    List<RoomDto.Response> getAvailableRoomsFiltered(RoomDto.AvailabilityRequest request);

    Room getRoomEntityById(Long roomId);
}
