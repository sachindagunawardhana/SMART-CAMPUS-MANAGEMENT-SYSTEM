package com.scms.repository;

import com.scms.entity.MaintenanceRequest;
import com.scms.entity.User;
import com.scms.enums.MaintenanceStatus;
import com.scms.enums.Priority;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MaintenanceRequestRepository extends JpaRepository<MaintenanceRequest, Long> {

    List<MaintenanceRequest> findByStatus(MaintenanceStatus status);

    List<MaintenanceRequest> findByReportedBy(User user);

    List<MaintenanceRequest> findByAssignedTo(User staff);

    List<MaintenanceRequest> findByPriority(Priority priority);

    List<MaintenanceRequest> findByPriorityAndStatus(Priority priority, MaintenanceStatus status);

    List<MaintenanceRequest> findByStatusOrderByCreatedAtDesc(MaintenanceStatus status);

    long countByStatus(MaintenanceStatus status);
}
