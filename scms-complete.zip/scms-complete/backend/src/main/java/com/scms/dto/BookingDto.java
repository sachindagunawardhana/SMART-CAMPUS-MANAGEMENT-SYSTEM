package com.scms.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDateTime;

public class BookingDto {

    @Data
    public static class CreateRequest {
        @NotNull(message = "Room ID is required")
        private Long roomId;

        @NotNull(message = "Start time is required")
        private LocalDateTime startTime;

        @NotNull(message = "End time is required")
        private LocalDateTime endTime;

        @NotBlank(message = "Purpose is required")
        @Size(max = 300)
        private String purpose;

        @Min(1) @Max(500)
        private Integer attendeesCount;
    }

    @Data
    public static class UpdateRequest {
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private String purpose;
        private Integer attendeesCount;
    }

    @Data
    public static class CancelRequest {
        @NotBlank(message = "Cancellation reason is required")
        private String reason;
    }

    @Data
    public static class Response {
        private Long id;
        private Long roomId;
        private String roomNumber;
        private String roomName;
        private Long bookedById;
        private String bookedByName;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private String purpose;
        private String status;
        private Integer attendeesCount;
        private String cancellationReason;
        private LocalDateTime createdAt;
    }
}
