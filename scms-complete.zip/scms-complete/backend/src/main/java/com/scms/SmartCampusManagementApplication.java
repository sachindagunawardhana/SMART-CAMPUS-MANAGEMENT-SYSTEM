package com.scms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Smart Campus Management System (SCMS)
 * Entry point for the Spring Boot application.
 *
 * Architecture: Layered (Controller → Service → Repository)
 * Patterns: Factory, Facade, Observer, Strategy
 */
@SpringBootApplication
@EnableAsync
public class SmartCampusManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartCampusManagementApplication.class, args);
    }
}
