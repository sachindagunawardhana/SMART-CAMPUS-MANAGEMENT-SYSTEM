package com.scms.entity;

import com.scms.enums.UserRole;
import jakarta.persistence.*;
import lombok.*;

/**
 * Student user — can book study rooms and view maintenance updates.
 */
@Entity
@DiscriminatorValue("STUDENT")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Student extends User {

    @Column(name = "student_id", unique = true)
    private String studentId;

    @Column(name = "faculty")
    private String faculty;

    @Column(name = "year_of_study")
    private Integer yearOfStudy;

    public Student(String firstName, String lastName, String email,
                   String password, String studentId, String faculty, Integer yearOfStudy) {
        super(null, firstName, lastName, email, password,
              UserRole.STUDENT, true, null, null, null);
        this.studentId = studentId;
        this.faculty = faculty;
        this.yearOfStudy = yearOfStudy;
    }

    @Override
    public String getRoleDescription() {
        return "Student - Year " + yearOfStudy + " | " + faculty;
    }
}
