package com.scms.service.impl;

import com.scms.dto.BookingDto;
import com.scms.entity.*;
import com.scms.enums.BookingStatus;
import com.scms.enums.NotificationType;
import com.scms.exception.*;
import com.scms.repository.BookingRepository;
import com.scms.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Core booking logic:
 *  - Double-booking prevention via overlapping query
 *  - Observer notifications on confirm/cancel
 *  - Role-agnostic: any authenticated user can book
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class BookingServiceImpl implements BookingService {

    private final BookingRepository    bookingRepository;
    private final RoomService          roomService;
    private final UserService          userService;
    private final NotificationService  notificationService;

    // ── Create ─────────────────────────────────────────────────────────────

    @Override
    public BookingDto.Response createBooking(BookingDto.CreateRequest req) {
        validateTimeRange(req.getStartTime(), req.getEndTime());

        Room room = roomService.getRoomEntityById(req.getRoomId());
        if (!room.isActive()) {
            throw new InvalidBookingException("room",
                    "Room '" + room.getRoomName() + "' is not available for booking.");
        }

        // ── Double-booking guard ───────────────────────────────────────────
        List<Booking> conflicts = bookingRepository.findOverlappingBookings(
                room, req.getStartTime(), req.getEndTime(), null);

        if (!conflicts.isEmpty()) {
            throw new InvalidBookingException(
                    "The room is already booked for the requested time slot. " +
                    "Conflicting booking: " + conflicts.get(0).getStartTime() +
                    " – " + conflicts.get(0).getEndTime());
        }

        if (req.getAttendeesCount() != null && req.getAttendeesCount() > room.getCapacity()) {
            throw new InvalidBookingException("attendeesCount",
                    "Attendees (" + req.getAttendeesCount() +
                    ") exceed room capacity (" + room.getCapacity() + ").");
        }

        User currentUser = userService.getCurrentUser();

        Booking booking = Booking.builder()
                .room(room)
                .bookedBy(currentUser)
                .startTime(req.getStartTime())
                .endTime(req.getEndTime())
                .purpose(req.getPurpose())
                .attendeesCount(req.getAttendeesCount())
                .status(BookingStatus.PENDING)
                .build();

        Booking saved = bookingRepository.save(booking);
        log.info("Booking created: id={} room={} user={}",
                saved.getId(), room.getRoomNumber(), currentUser.getEmail());

        // Auto-confirm and notify
        saved.confirm();
        bookingRepository.save(saved);
        sendBookingConfirmedNotification(saved);

        return toResponse(saved);
    }

    // ── Confirm ────────────────────────────────────────────────────────────

    @Override
    public BookingDto.Response confirmBooking(Long bookingId) {
        Booking booking = getBookingEntity(bookingId);

        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new InvalidBookingException(
                    "Only PENDING bookings can be confirmed. Current status: " + booking.getStatus());
        }

        booking.confirm();
        Booking saved = bookingRepository.save(booking);
        sendBookingConfirmedNotification(saved);
        return toResponse(saved);
    }

    // ── Cancel ─────────────────────────────────────────────────────────────

    @Override
    public BookingDto.Response cancelBooking(Long bookingId, BookingDto.CancelRequest req) {
        Booking booking = getBookingEntity(bookingId);
        User current = userService.getCurrentUser();

        // Only the booking owner or an Admin can cancel
        boolean isOwner = booking.getBookedBy().getId().equals(current.getId());
        boolean isAdmin  = current.getRole().name().equals("ADMIN");

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedAccessException(
                    "You are not authorised to cancel this booking.");
        }

        if (booking.getStatus() == BookingStatus.CANCELLED ||
            booking.getStatus() == BookingStatus.COMPLETED) {
            throw new InvalidBookingException(
                    "Booking cannot be cancelled. Current status: " + booking.getStatus());
        }

        booking.cancel(req.getReason());
        Booking saved = bookingRepository.save(booking);

        // Observer notification — cancellation
        notificationService.sendNotification(
                booking.getBookedBy(),
                "Booking Cancelled",
                "Your booking for " + booking.getRoom().getRoomName() +
                " on " + booking.getStartTime().toLocalDate() + " has been cancelled. " +
                "Reason: " + req.getReason(),
                NotificationType.BOOKING_CANCELLED,
                saved.getId(), "BOOKING");

        log.info("Booking cancelled: id={}", bookingId);
        return toResponse(saved);
    }

    // ── Read ───────────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public BookingDto.Response getBookingById(Long bookingId) {
        return toResponse(getBookingEntity(bookingId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookingDto.Response> getMyBookings() {
        User current = userService.getCurrentUser();
        return bookingRepository.findByBookedByOrderByStartTimeDesc(current)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookingDto.Response> getAllBookings() {
        return bookingRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookingDto.Response> getBookingsByRoom(Long roomId) {
        Room room = roomService.getRoomEntityById(roomId);
        return bookingRepository.findByRoomOrderByStartTimeDesc(room)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private Booking getBookingEntity(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", "id", id));
    }

    private void validateTimeRange(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null) {
            throw new InvalidBookingException("Start and end time are required.");
        }
        if (!start.isBefore(end)) {
            throw new InvalidBookingException("startTime",
                    "Start time must be before end time.");
        }
        if (start.isBefore(LocalDateTime.now())) {
            throw new InvalidBookingException("startTime",
                    "Cannot book a room in the past.");
        }
    }

    private void sendBookingConfirmedNotification(Booking booking) {
        notificationService.sendNotification(
                booking.getBookedBy(),
                "Booking Confirmed",
                "Your booking for " + booking.getRoom().getRoomName() +
                " (" + booking.getRoom().getRoomNumber() + ")" +
                " from " + booking.getStartTime() + " to " + booking.getEndTime() +
                " has been confirmed.",
                NotificationType.BOOKING_CONFIRMED,
                booking.getId(), "BOOKING");
    }

    // ── Mapper ─────────────────────────────────────────────────────────────

    private BookingDto.Response toResponse(Booking b) {
        BookingDto.Response res = new BookingDto.Response();
        res.setId(b.getId());
        res.setRoomId(b.getRoom().getId());
        res.setRoomNumber(b.getRoom().getRoomNumber());
        res.setRoomName(b.getRoom().getRoomName());
        res.setBookedById(b.getBookedBy().getId());
        res.setBookedByName(b.getBookedBy().getFullName());
        res.setStartTime(b.getStartTime());
        res.setEndTime(b.getEndTime());
        res.setPurpose(b.getPurpose());
        res.setStatus(b.getStatus().name());
        res.setAttendeesCount(b.getAttendeesCount());
        res.setCancellationReason(b.getCancellationReason());
        res.setCreatedAt(b.getCreatedAt());
        return res;
    }
}
