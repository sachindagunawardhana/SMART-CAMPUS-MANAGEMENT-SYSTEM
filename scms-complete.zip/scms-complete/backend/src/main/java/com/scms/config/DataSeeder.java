package com.scms.config;

import com.scms.dto.AuthDto;
import com.scms.entity.Room;
import com.scms.enums.RoomType;
import com.scms.repository.RoomRepository;
import com.scms.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Seeds initial demo data into the H2 in-memory database on startup.
 * Provides test accounts for all three roles and sample rooms.
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataSeeder {

    private final UserService   userService;
    private final RoomRepository roomRepository;

    @Bean
    public CommandLineRunner seedData() {
        return args -> {
            log.info("=== Seeding SCMS demo data ===");

            // ── Users ──────────────────────────────────────────────────────

            // Admin
            AuthDto.RegisterRequest admin = new AuthDto.RegisterRequest();
            admin.setFirstName("Alice");
            admin.setLastName("Admin");
            admin.setEmail("admin@scms.com");
            admin.setPassword("Admin@123");
            admin.setRole("ADMIN");
            admin.setDepartment("IT Operations");
            userService.registerUser(admin);

            // Staff
            AuthDto.RegisterRequest staff = new AuthDto.RegisterRequest();
            staff.setFirstName("Bob");
            staff.setLastName("Staff");
            staff.setEmail("staff@scms.com");
            staff.setPassword("Staff@123");
            staff.setRole("STAFF");
            staff.setEmployeeId("EMP001");
            staff.setDepartment("Facilities");
            staff.setPosition("Maintenance Engineer");
            userService.registerUser(staff);

            // Student
            AuthDto.RegisterRequest student = new AuthDto.RegisterRequest();
            student.setFirstName("Charlie");
            student.setLastName("Student");
            student.setEmail("student@scms.com");
            student.setPassword("Student@123");
            student.setRole("STUDENT");
            student.setStudentId("STU2024001");
            student.setFaculty("Computer Science");
            student.setYearOfStudy(2);
            userService.registerUser(student);

            // ── Rooms ──────────────────────────────────────────────────────

            roomRepository.save(Room.builder()
                    .roomNumber("LH-101")
                    .roomName("Main Lecture Hall")
                    .roomType(RoomType.LECTURE_HALL)
                    .capacity(200)
                    .building("Block A")
                    .floorNumber(1)
                    .hasProjector(true)
                    .hasWhiteboard(true)
                    .hasAirConditioning(true)
                    .description("Large lecture hall with 200 seats and AV equipment.")
                    .active(true)
                    .build());

            roomRepository.save(Room.builder()
                    .roomNumber("LAB-201")
                    .roomName("Computer Science Lab")
                    .roomType(RoomType.LABORATORY)
                    .capacity(40)
                    .building("Block B")
                    .floorNumber(2)
                    .hasProjector(true)
                    .hasWhiteboard(false)
                    .hasAirConditioning(true)
                    .description("CS lab with 40 workstations.")
                    .active(true)
                    .build());

            roomRepository.save(Room.builder()
                    .roomNumber("SR-301")
                    .roomName("Seminar Room A")
                    .roomType(RoomType.SEMINAR_ROOM)
                    .capacity(30)
                    .building("Block C")
                    .floorNumber(3)
                    .hasProjector(true)
                    .hasWhiteboard(true)
                    .hasAirConditioning(true)
                    .description("Seminar room ideal for group discussions.")
                    .active(true)
                    .build());

            roomRepository.save(Room.builder()
                    .roomNumber("CR-401")
                    .roomName("Board Conference Room")
                    .roomType(RoomType.CONFERENCE_ROOM)
                    .capacity(20)
                    .building("Admin Block")
                    .floorNumber(4)
                    .hasProjector(true)
                    .hasWhiteboard(true)
                    .hasAirConditioning(true)
                    .description("Executive conference room for board meetings.")
                    .active(true)
                    .build());

            roomRepository.save(Room.builder()
                    .roomNumber("STUDY-101")
                    .roomName("Student Study Pod 1")
                    .roomType(RoomType.STUDY_ROOM)
                    .capacity(8)
                    .building("Library")
                    .floorNumber(1)
                    .hasProjector(false)
                    .hasWhiteboard(true)
                    .hasAirConditioning(true)
                    .description("Quiet study pod for small groups.")
                    .active(true)
                    .build());

            log.info("=== Seeding complete. 3 users, 5 rooms created ===");
            log.info("Login credentials:");
            log.info("  Admin:   admin@scms.com   / Admin@123");
            log.info("  Staff:   staff@scms.com   / Staff@123");
            log.info("  Student: student@scms.com / Student@123");
        };
    }
}
