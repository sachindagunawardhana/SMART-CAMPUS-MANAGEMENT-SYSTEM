package com.scms.enums;

public enum RoomType {
    LECTURE_HALL,
    LABORATORY,
    SEMINAR_ROOM,
    CONFERENCE_ROOM,
    STUDY_ROOM,
    AUDITORIUM
}
