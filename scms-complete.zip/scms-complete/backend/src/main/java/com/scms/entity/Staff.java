package com.scms.entity;

import com.scms.enums.UserRole;
import jakarta.persistence.*;
import lombok.*;

/**
 * Staff member — can book rooms and submit/resolve maintenance requests.
 */
@Entity
@DiscriminatorValue("STAFF")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Staff extends User {

    @Column(name = "employee_id", unique = true)
    private String employeeId;

    @Column(name = "department")
    private String department;

    @Column(name = "position")
    private String position;

    public Staff(String firstName, String lastName, String email,
                 String password, String employeeId, String department, String position) {
        super(null, firstName, lastName, email, password,
              UserRole.STAFF, true, null, null, null);
        this.employeeId = employeeId;
        this.department = department;
        this.position = position;
    }

    @Override
    public String getRoleDescription() {
        return "Staff Member - " + position + " at " + department;
    }
}
