package com.scms.controller;

import com.scms.dto.BookingDto;
import com.scms.service.BookingService;
import com.scms.service.impl.BookingFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Booking REST API.
 * Uses BookingFacade for multi-step workflows (Facade Pattern).
 */
@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingFacade  bookingFacade;
    private final BookingService bookingService;

    /**
     * POST /api/bookings
     * Any authenticated user can book a room.
     * Facade handles: availability check → create → confirm → notify.
     */
    @PostMapping
    public ResponseEntity<BookingDto.Response> createBooking(
            @Valid @RequestBody BookingDto.CreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(bookingFacade.bookRoom(request));
    }

    /**
     * DELETE /api/bookings/{id}/cancel
     * Owner or Admin can cancel.
     */
    @PatchMapping("/{bookingId}/cancel")
    public ResponseEntity<BookingDto.Response> cancelBooking(
            @PathVariable Long bookingId,
            @RequestBody BookingDto.CancelRequest request) {
        return ResponseEntity.ok(bookingFacade.cancelBooking(bookingId, request));
    }

    /**
     * GET /api/bookings/my
     * Returns all bookings made by the current user.
     */
    @GetMapping("/my")
    public ResponseEntity<List<BookingDto.Response>> getMyBookings() {
        return ResponseEntity.ok(bookingService.getMyBookings());
    }

    /**
     * GET /api/bookings
     * Admin-only: see all bookings in the system.
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<BookingDto.Response>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    /**
     * GET /api/bookings/{id}
     */
    @GetMapping("/{bookingId}")
    public ResponseEntity<BookingDto.Response> getBookingById(@PathVariable Long bookingId) {
        return ResponseEntity.ok(bookingService.getBookingById(bookingId));
    }

    /**
     * GET /api/bookings/room/{roomId}
     * Admin/Staff can view a room's bookings.
     */
    @GetMapping("/room/{roomId}")
    @PreAuthorize("hasAnyRole('ADMIN','STAFF')")
    public ResponseEntity<List<BookingDto.Response>> getBookingsByRoom(
            @PathVariable Long roomId) {
        return ResponseEntity.ok(bookingService.getBookingsByRoom(roomId));
    }
}
