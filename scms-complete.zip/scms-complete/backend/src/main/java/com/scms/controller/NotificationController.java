package com.scms.controller;

import com.scms.dto.NotificationDto;
import com.scms.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Notification REST API.
 * All endpoints serve the currently authenticated user.
 */
@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping
    public ResponseEntity<List<NotificationDto.Response>> getMyNotifications() {
        return ResponseEntity.ok(notificationService.getMyNotifications());
    }

    @GetMapping("/unread")
    public ResponseEntity<List<NotificationDto.Response>> getUnread() {
        return ResponseEntity.ok(notificationService.getMyUnreadNotifications());
    }

    /** Returns a plain long — the UI reads this directly for the badge. */
    @GetMapping("/unread/count")
    public ResponseEntity<Long> countUnread() {
        return ResponseEntity.ok(notificationService.countUnread());
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<String> markAsReadPut(@PathVariable Long id) {
        notificationService.markAsRead(id);
        return ResponseEntity.ok("Notification marked as read.");
    }

    @PatchMapping("/{id}/read")
    public ResponseEntity<String> markAsReadPatch(@PathVariable Long id) {
        notificationService.markAsRead(id);
        return ResponseEntity.ok("Notification marked as read.");
    }

    @PutMapping("/read-all")
    public ResponseEntity<String> markAllAsReadPut() {
        notificationService.markAllAsRead();
        return ResponseEntity.ok("All notifications marked as read.");
    }

    @PatchMapping("/read-all")
    public ResponseEntity<String> markAllAsReadPatch() {
        notificationService.markAllAsRead();
        return ResponseEntity.ok("All notifications marked as read.");
    }
}
