package com.scms.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsDto {

    // Booking stats
    private long totalBookings;
    private long confirmedBookings;
    private long cancelledBookings;
    private long pendingBookings;

    // Maintenance stats
    private long openMaintenanceRequests;
    private long resolvedMaintenanceRequests;
    private long totalMaintenanceRequests;

    // Room stats
    private long totalRooms;
    private long activeRooms;

    // Top booked rooms
    private List<RoomBookingCount> mostBookedRooms;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RoomBookingCount {
        private String roomName;
        private String roomNumber;
        private long bookingCount;
    }
}
