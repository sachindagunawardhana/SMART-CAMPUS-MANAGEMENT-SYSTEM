package com.scms.service;

import com.scms.dto.MaintenanceDto;

import java.util.List;

public interface MaintenanceService {

    MaintenanceDto.Response createRequest(MaintenanceDto.CreateRequest request);

    MaintenanceDto.Response assignRequest(Long requestId, MaintenanceDto.AssignRequest assign);

    MaintenanceDto.Response updateStatus(Long requestId, MaintenanceDto.UpdateStatusRequest update);

    MaintenanceDto.Response getById(Long requestId);

    List<MaintenanceDto.Response> getAllRequests();

    List<MaintenanceDto.Response> getMyRequests();

    List<MaintenanceDto.Response> getAssignedToMe();
}
