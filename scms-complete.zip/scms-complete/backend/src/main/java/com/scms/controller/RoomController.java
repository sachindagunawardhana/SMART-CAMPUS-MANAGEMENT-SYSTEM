package com.scms.controller;

import com.scms.dto.RoomDto;
import com.scms.service.RoomService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST API for Room management.
 *
 * GET  — all authenticated users
 * POST/PUT/DELETE — Admin only (enforced at SecurityConfig + @PreAuthorize)
 */
@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    // ── Admin mutations ────────────────────────────────────────────────────

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RoomDto.Response> createRoom(
            @Valid @RequestBody RoomDto.CreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(roomService.createRoom(request));
    }

    @PutMapping("/{roomId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RoomDto.Response> updateRoom(
            @PathVariable Long roomId,
            @RequestBody RoomDto.UpdateRequest request) {
        return ResponseEntity.ok(roomService.updateRoom(roomId, request));
    }

    @PatchMapping("/{roomId}/deactivate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deactivateRoom(@PathVariable Long roomId) {
        roomService.deactivateRoom(roomId);
        return ResponseEntity.ok("Room deactivated successfully.");
    }

    @PatchMapping("/{roomId}/activate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> activateRoom(@PathVariable Long roomId) {
        roomService.activateRoom(roomId);
        return ResponseEntity.ok("Room activated successfully.");
    }

    // ── Read — all authenticated users ─────────────────────────────────────

    @GetMapping
    public ResponseEntity<List<RoomDto.Response>> getAllRooms() {
        return ResponseEntity.ok(roomService.getAllRooms());
    }

    @GetMapping("/active")
    public ResponseEntity<List<RoomDto.Response>> getActiveRooms() {
        return ResponseEntity.ok(roomService.getActiveRooms());
    }

    @GetMapping("/{roomId}")
    public ResponseEntity<RoomDto.Response> getRoomById(@PathVariable Long roomId) {
        return ResponseEntity.ok(roomService.getRoomById(roomId));
    }

    /**
     * POST /api/rooms/available
     * Returns rooms with no confirmed/pending bookings in the given slot.
     */
    @PostMapping("/available")
    public ResponseEntity<List<RoomDto.Response>> getAvailableRooms(
            @Valid @RequestBody RoomDto.AvailabilityRequest request) {
        return ResponseEntity.ok(roomService.getAvailableRoomsFiltered(request));
    }
}
