package com.scms.service.impl;

import com.scms.dto.AnalyticsDto;
import com.scms.enums.BookingStatus;
import com.scms.enums.MaintenanceStatus;
import com.scms.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Analytics service — aggregates system statistics for Admin dashboard.
 * Bonus feature: most booked rooms ranking.
 */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AnalyticsService {

    private final BookingRepository            bookingRepository;
    private final MaintenanceRequestRepository maintenanceRepository;
    private final RoomRepository               roomRepository;

    public AnalyticsDto getDashboardStats() {
        // Booking stats
        long totalBookings     = bookingRepository.count();
        long confirmed         = bookingRepository.countByStatus(BookingStatus.CONFIRMED);
        long cancelled         = bookingRepository.countByStatus(BookingStatus.CANCELLED);
        long pending           = bookingRepository.countByStatus(BookingStatus.PENDING);

        // Maintenance stats
        long openMaintenance   = maintenanceRepository.countByStatus(MaintenanceStatus.OPEN);
        long resolvedMaint     = maintenanceRepository.countByStatus(MaintenanceStatus.RESOLVED);
        long totalMaint        = maintenanceRepository.count();

        // Room stats
        long totalRooms        = roomRepository.count();
        long activeRooms       = roomRepository.findByActiveTrue().size();

        // Most booked rooms (raw Object[] → DTO)
        List<AnalyticsDto.RoomBookingCount> topRooms =
                roomRepository.findMostBookedRooms().stream()
                        .limit(5)
                        .map(row -> new AnalyticsDto.RoomBookingCount(
                                (String) row[0],
                                (String) row[1],
                                ((Number) row[2]).longValue()))
                        .collect(Collectors.toList());

        return AnalyticsDto.builder()
                .totalBookings(totalBookings)
                .confirmedBookings(confirmed)
                .cancelledBookings(cancelled)
                .pendingBookings(pending)
                .openMaintenanceRequests(openMaintenance)
                .resolvedMaintenanceRequests(resolvedMaint)
                .totalMaintenanceRequests(totalMaint)
                .totalRooms(totalRooms)
                .activeRooms(activeRooms)
                .mostBookedRooms(topRooms)
                .build();
    }
}
