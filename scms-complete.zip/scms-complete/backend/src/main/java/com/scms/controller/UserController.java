package com.scms.controller;

import com.scms.entity.User;
import com.scms.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * User management REST API — Admin only (except /me).
 */
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    /** GET /api/users — all users (admin). Returns list of user summary DTOs. */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Map<String, Object>>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        List<Map<String, Object>> result = users.stream().map(u -> {
            Map<String, Object> m = new java.util.LinkedHashMap<>();
            m.put("id",         u.getId());
            m.put("fullName",   u.getFullName());
            m.put("email",      u.getEmail());
            m.put("role",       u.getRole().name());
            m.put("active",     u.isActive());
            m.put("createdAt",  u.getCreatedAt());
            // role-specific fields via instanceof
            if (u instanceof com.scms.entity.Staff s) {
                m.put("employeeId",  s.getEmployeeId());
                m.put("department",  s.getDepartment());
                m.put("position",    s.getPosition());
            } else if (u instanceof com.scms.entity.Student st) {
                m.put("studentId",   st.getStudentId());
                m.put("faculty",     st.getFaculty());
                m.put("yearOfStudy", st.getYearOfStudy());
            } else if (u instanceof com.scms.entity.Admin a) {
                m.put("department",  a.getDepartment());
            }
            return m;
        }).toList();
        return ResponseEntity.ok(result);
    }

    /** GET /api/users/me — current user's own profile */
    @GetMapping("/me")
    public ResponseEntity<Map<String, Object>> getMe() {
        User u = userService.getCurrentUser();
        Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("id",       u.getId());
        m.put("fullName", u.getFullName());
        m.put("email",    u.getEmail());
        m.put("role",     u.getRole().name());
        m.put("active",   u.isActive());
        return ResponseEntity.ok(m);
    }

    /** GET /api/users/{id} */
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }
}
