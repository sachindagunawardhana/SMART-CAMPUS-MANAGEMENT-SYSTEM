package com.scms.dto;

import com.scms.enums.RoomType;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDateTime;

public class RoomDto {

    @Data
    public static class CreateRequest {
        @NotBlank(message = "Room number is required")
        private String roomNumber;

        @NotBlank(message = "Room name is required")
        private String roomName;

        @NotNull(message = "Room type is required")
        private RoomType roomType;

        @Min(value = 1, message = "Capacity must be at least 1")
        private int capacity;

        private String building;
        private Integer floorNumber;
        private boolean hasProjector;
        private boolean hasWhiteboard;
        private boolean hasAirConditioning;
        private String description;
    }

    @Data
    public static class UpdateRequest {
        private String roomName;
        private Integer capacity;
        private String building;
        private Integer floorNumber;
        private Boolean hasProjector;
        private Boolean hasWhiteboard;
        private Boolean hasAirConditioning;
        private String description;
    }

    @Data
    public static class Response {
        private Long id;
        private String roomNumber;
        private String roomName;
        private String roomType;
        private int capacity;
        private String building;
        private Integer floorNumber;
        private boolean hasProjector;
        private boolean hasWhiteboard;
        private boolean hasAirConditioning;
        private boolean active;
        private String description;
        private LocalDateTime createdAt;
    }

    @Data
    public static class AvailabilityRequest {
        @NotNull private LocalDateTime startTime;
        @NotNull private LocalDateTime endTime;
        private Integer minCapacity;
        private RoomType roomType;
    }
}
