package com.scms.enums;

public enum UserRole {
    ADMIN,
    STAFF,
    STUDENT
}
