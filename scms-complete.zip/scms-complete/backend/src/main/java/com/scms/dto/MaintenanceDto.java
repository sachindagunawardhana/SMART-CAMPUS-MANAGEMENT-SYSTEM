package com.scms.dto;

import com.scms.enums.Priority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

public class MaintenanceDto {

    @Data
    public static class CreateRequest {
        @NotBlank(message = "Title is required")
        private String title;

        @NotBlank(message = "Description is required")
        private String description;

        @NotNull(message = "Priority is required")
        private Priority priority;

        private Long roomId;  // optional – could be a general facility issue
    }

    @Data
    public static class AssignRequest {
        @NotNull(message = "Staff user ID is required")
        private Long staffUserId;
    }

    @Data
    public static class UpdateStatusRequest {
        @NotBlank(message = "Status is required")
        private String status;   // IN_PROGRESS / RESOLVED / CLOSED
        private String resolutionNotes;
    }

    @Data
    public static class Response {
        private Long id;
        private String title;
        private String description;
        private String priority;
        private String status;
        private Long roomId;
        private String roomName;
        private Long reportedById;
        private String reportedByName;
        private Long assignedToId;
        private String assignedToName;
        private String resolutionNotes;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        private LocalDateTime resolvedAt;
    }
}
