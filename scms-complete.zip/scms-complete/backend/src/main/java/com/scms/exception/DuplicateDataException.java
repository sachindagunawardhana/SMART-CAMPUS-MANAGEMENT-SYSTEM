package com.scms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when attempting to create a resource that already exists
 * (e.g., duplicate room number, duplicate email).
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class DuplicateDataException extends RuntimeException {

    private final String field;
    private final Object value;

    public DuplicateDataException(String message) {
        super(message);
        this.field = null;
        this.value = null;
    }

    public DuplicateDataException(String field, Object value) {
        super("Duplicate value '" + value + "' for field: " + field);
        this.field = field;
        this.value = value;
    }

    public String getField() { return field; }
    public Object getValue() { return value; }
}
