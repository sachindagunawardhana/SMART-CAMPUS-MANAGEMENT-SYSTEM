package com.scms.service.impl;

import com.scms.dto.NotificationDto;
import com.scms.entity.Notification;
import com.scms.entity.User;
import com.scms.enums.NotificationType;
import com.scms.exception.ResourceNotFoundException;
import com.scms.repository.NotificationRepository;
import com.scms.service.NotificationObserver;
import com.scms.service.NotificationService;
import com.scms.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Observer Pattern — Concrete Subject + Concrete Observer.
 *
 * NotificationServiceImpl acts as:
 *  1) The Subject: maintains a list of observers and notifies them.
 *  2) A Concrete Observer: persists notifications to the database.
 *
 * Additional observers (e.g. EmailNotificationObserver, SMSObserver)
 * can be registered at runtime without modifying this class — Open/Closed Principle.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class NotificationServiceImpl implements NotificationService, NotificationObserver {

    private final NotificationRepository notificationRepository;
    private final UserService userService;

    // Observer registry — other observers (email, SMS, push) register here
    private final List<NotificationObserver> observers = new ArrayList<>();

    // ── NotificationPublisher (Subject) ────────────────────────────────────

    @Override
    public void registerObserver(NotificationObserver observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
            log.info("Registered notification observer: {}", observer.getClass().getSimpleName());
        }
    }

    @Override
    public void removeObserver(NotificationObserver observer) {
        observers.remove(observer);
    }

    @Override
    @Async
    public void notifyObservers(NotificationType type, User recipient, String title,
                                String message, Long referenceId, String referenceType) {
        // Notify self first (persist to DB)
        onEvent(type, recipient, title, message, referenceId, referenceType);

        // Then notify all registered external observers asynchronously
        observers.forEach(observer -> {
            try {
                observer.onEvent(type, recipient, title, message, referenceId, referenceType);
            } catch (Exception e) {
                log.error("Observer {} failed: {}", observer.getClass().getSimpleName(), e.getMessage());
            }
        });
    }

    // ── NotificationObserver (DB persistence) ──────────────────────────────

    @Override
    public void onEvent(NotificationType type, User recipient, String title,
                        String message, Long referenceId, String referenceType) {
        Notification notification = Notification.builder()
                .title(title)
                .message(message)
                .type(type)
                .recipient(recipient)
                .referenceId(referenceId)
                .referenceType(referenceType)
                .read(false)
                .build();

        notificationRepository.save(notification);
        log.debug("Notification saved for user [{}]: {}", recipient.getEmail(), title);
    }

    // ── NotificationService ────────────────────────────────────────────────

    @Override
    public void sendNotification(User recipient, String title, String message,
                                 NotificationType type, Long referenceId, String referenceType) {
        notifyObservers(type, recipient, title, message, referenceId, referenceType);
    }

    @Override
    public void broadcastNotification(List<User> recipients, String title, String message,
                                      NotificationType type, Long referenceId, String referenceType) {
        recipients.forEach(user ->
                sendNotification(user, title, message, type, referenceId, referenceType));
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationDto.Response> getMyNotifications() {
        User current = userService.getCurrentUser();
        return notificationRepository
                .findByRecipientOrderByCreatedAtDesc(current)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationDto.Response> getMyUnreadNotifications() {
        User current = userService.getCurrentUser();
        return notificationRepository
                .findByRecipientAndReadFalseOrderByCreatedAtDesc(current)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public void markAsRead(Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification", "id", notificationId));

        User current = userService.getCurrentUser();
        if (!notification.getRecipient().getId().equals(current.getId())) {
            throw new com.scms.exception.UnauthorizedAccessException(
                    "You cannot mark another user's notification as read.");
        }

        notification.markAsRead();
        notificationRepository.save(notification);
    }

    @Override
    public void markAllAsRead() {
        User current = userService.getCurrentUser();
        notificationRepository.markAllAsReadForUser(current);
    }

    @Override
    @Transactional(readOnly = true)
    public long countUnread() {
        User current = userService.getCurrentUser();
        return notificationRepository.countByRecipientAndReadFalse(current);
    }

    // ── Mapper ─────────────────────────────────────────────────────────────

    private NotificationDto.Response toResponse(Notification n) {
        return new NotificationDto.Response(
                n.getId(),
                n.getTitle(),
                n.getMessage(),
                n.getType().name(),
                n.isRead(),
                n.getReferenceId(),
                n.getReferenceType(),
                n.getCreatedAt(),
                n.getReadAt()
        );
    }
}
