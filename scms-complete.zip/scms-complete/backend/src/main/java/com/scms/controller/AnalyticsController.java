package com.scms.controller;

import com.scms.dto.AnalyticsDto;
import com.scms.service.impl.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Analytics REST API — Admin only.
 * GET /api/analytics         → full dashboard stats (used by UI)
 * GET /api/analytics/dashboard → alias
 */
@RestController
@RequestMapping("/api/analytics")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping
    public ResponseEntity<AnalyticsDto> getAnalytics() {
        return ResponseEntity.ok(analyticsService.getDashboardStats());
    }

    @GetMapping("/dashboard")
    public ResponseEntity<AnalyticsDto> getDashboard() {
        return ResponseEntity.ok(analyticsService.getDashboardStats());
    }
}
