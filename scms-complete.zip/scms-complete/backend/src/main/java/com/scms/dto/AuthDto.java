package com.scms.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

public class AuthDto {

    @Data
    public static class LoginRequest {
        @Email(message = "Valid email required")
        @NotBlank(message = "Email is required")
        private String email;

        @NotBlank(message = "Password is required")
        private String password;
    }

    @Data
    public static class LoginResponse {
        private String token;
        private String type = "Bearer";
        private Long userId;
        private String email;
        private String fullName;
        private String role;

        public LoginResponse(String token, Long userId, String email,
                             String fullName, String role) {
            this.token = token;
            this.userId = userId;
            this.email = email;
            this.fullName = fullName;
            this.role = role;
        }
    }

    @Data
    public static class RegisterRequest {
        @NotBlank private String firstName;
        @NotBlank private String lastName;
        @Email   @NotBlank private String email;
        @NotBlank private String password;
        @NotBlank private String role;       // ADMIN / STAFF / STUDENT
        // Optional role-specific fields
        private String department;           // Admin / Staff
        private String position;            // Staff
        private String employeeId;          // Staff
        private String studentId;           // Student
        private String faculty;             // Student
        private Integer yearOfStudy;        // Student
    }
}
