package com.scms.service.impl;

import com.scms.dto.MaintenanceDto;
import com.scms.entity.*;
import com.scms.enums.MaintenanceStatus;
import com.scms.enums.NotificationType;
import com.scms.exception.*;
import com.scms.repository.MaintenanceRequestRepository;
import com.scms.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Maintenance request lifecycle management.
 * Observer notifications are triggered on every status change.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class MaintenanceServiceImpl implements MaintenanceService {

    private final MaintenanceRequestRepository maintenanceRepository;
    private final RoomService                  roomService;
    private final UserService                  userService;
    private final NotificationService          notificationService;

    // ── Create ─────────────────────────────────────────────────────────────

    @Override
    public MaintenanceDto.Response createRequest(MaintenanceDto.CreateRequest req) {
        User reporter = userService.getCurrentUser();

        MaintenanceRequest.MaintenanceRequestBuilder builder = MaintenanceRequest.builder()
                .title(req.getTitle())
                .description(req.getDescription())
                .priority(req.getPriority())
                .reportedBy(reporter)
                .status(MaintenanceStatus.OPEN);

        if (req.getRoomId() != null) {
            Room room = roomService.getRoomEntityById(req.getRoomId());
            builder.room(room);
        }

        MaintenanceRequest saved = maintenanceRepository.save(builder.build());
        log.info("Maintenance request created: id={} by={}", saved.getId(), reporter.getEmail());

        // Notify the reporter
        notificationService.sendNotification(
                reporter,
                "Maintenance Request Submitted",
                "Your maintenance request '" + saved.getTitle() + "' has been submitted " +
                "with priority: " + saved.getPriority().name() + ". We will assign it shortly.",
                NotificationType.MAINTENANCE_CREATED,
                saved.getId(), "MAINTENANCE");

        return toResponse(saved);
    }

    // ── Assign ─────────────────────────────────────────────────────────────

    @Override
    public MaintenanceDto.Response assignRequest(Long requestId,
                                                  MaintenanceDto.AssignRequest req) {
        MaintenanceRequest request = getEntity(requestId);
        User staff = userService.getUserById(req.getStaffUserId());

        if (staff.getRole().name().equals("STUDENT")) {
            throw new UnauthorizedAccessException(
                    "Maintenance requests can only be assigned to Staff or Admin.");
        }

        request.assignTo(staff);
        MaintenanceRequest saved = maintenanceRepository.save(request);
        log.info("Maintenance request {} assigned to {}", requestId, staff.getEmail());

        // Notify assignee
        notificationService.sendNotification(
                staff,
                "Maintenance Request Assigned",
                "You have been assigned maintenance request: '" + saved.getTitle() +
                "' (Priority: " + saved.getPriority() + ").",
                NotificationType.MAINTENANCE_ASSIGNED,
                saved.getId(), "MAINTENANCE");

        // Notify reporter
        notificationService.sendNotification(
                request.getReportedBy(),
                "Your Request Has Been Assigned",
                "Your maintenance request '" + saved.getTitle() +
                "' has been assigned to " + staff.getFullName() + ".",
                NotificationType.MAINTENANCE_UPDATED,
                saved.getId(), "MAINTENANCE");

        return toResponse(saved);
    }

    // ── Update Status ──────────────────────────────────────────────────────

    @Override
    public MaintenanceDto.Response updateStatus(Long requestId,
                                                 MaintenanceDto.UpdateStatusRequest req) {
        MaintenanceRequest request = getEntity(requestId);
        User current = userService.getCurrentUser();

        // Only the assignee or admin can update status
        boolean isAssignee = request.getAssignedTo() != null &&
                             request.getAssignedTo().getId().equals(current.getId());
        boolean isAdmin    = current.getRole().name().equals("ADMIN");

        if (!isAssignee && !isAdmin) {
            throw new UnauthorizedAccessException(
                    "Only the assigned staff or an Admin can update this request.");
        }

        MaintenanceStatus newStatus = MaintenanceStatus.valueOf(req.getStatus().toUpperCase());

        switch (newStatus) {
            case IN_PROGRESS -> request.setStatus(MaintenanceStatus.IN_PROGRESS);
            case RESOLVED    -> request.resolve(req.getResolutionNotes());
            case CLOSED      -> request.close();
            default -> throw new InvalidBookingException(
                    "Invalid status transition to: " + newStatus);
        }

        MaintenanceRequest saved = maintenanceRepository.save(request);
        log.info("Maintenance {} status updated to {}", requestId, newStatus);

        // Observer pattern: notify reporter of status change
        NotificationType nType = (newStatus == MaintenanceStatus.RESOLVED)
                ? NotificationType.MAINTENANCE_RESOLVED
                : NotificationType.MAINTENANCE_UPDATED;

        notificationService.sendNotification(
                request.getReportedBy(),
                "Maintenance Request Updated",
                "Your request '" + saved.getTitle() + "' status changed to: " +
                newStatus.name() +
                (req.getResolutionNotes() != null ? ". Notes: " + req.getResolutionNotes() : ""),
                nType,
                saved.getId(), "MAINTENANCE");

        return toResponse(saved);
    }

    // ── Read ───────────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public MaintenanceDto.Response getById(Long id) {
        return toResponse(getEntity(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<MaintenanceDto.Response> getAllRequests() {
        return maintenanceRepository.findAll().stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<MaintenanceDto.Response> getMyRequests() {
        User current = userService.getCurrentUser();
        return maintenanceRepository.findByReportedBy(current).stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<MaintenanceDto.Response> getAssignedToMe() {
        User current = userService.getCurrentUser();
        return maintenanceRepository.findByAssignedTo(current).stream()
                .map(this::toResponse).collect(Collectors.toList());
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private MaintenanceRequest getEntity(Long id) {
        return maintenanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "MaintenanceRequest", "id", id));
    }

    // ── Mapper ─────────────────────────────────────────────────────────────

    private MaintenanceDto.Response toResponse(MaintenanceRequest m) {
        MaintenanceDto.Response res = new MaintenanceDto.Response();
        res.setId(m.getId());
        res.setTitle(m.getTitle());
        res.setDescription(m.getDescription());
        res.setPriority(m.getPriority().name());
        res.setStatus(m.getStatus().name());
        res.setReportedById(m.getReportedBy().getId());
        res.setReportedByName(m.getReportedBy().getFullName());
        res.setCreatedAt(m.getCreatedAt());
        res.setUpdatedAt(m.getUpdatedAt());
        res.setResolvedAt(m.getResolvedAt());
        res.setResolutionNotes(m.getResolutionNotes());
        if (m.getRoom() != null) {
            res.setRoomId(m.getRoom().getId());
            res.setRoomName(m.getRoom().getRoomName());
        }
        if (m.getAssignedTo() != null) {
            res.setAssignedToId(m.getAssignedTo().getId());
            res.setAssignedToName(m.getAssignedTo().getFullName());
        }
        return res;
    }
}
