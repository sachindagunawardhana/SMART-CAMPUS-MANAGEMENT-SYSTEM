package com.scms.repository;

import com.scms.entity.Booking;
import com.scms.entity.Room;
import com.scms.entity.User;
import com.scms.enums.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByBookedByOrderByStartTimeDesc(User user);

    List<Booking> findByRoomOrderByStartTimeDesc(Room room);

    List<Booking> findByStatus(BookingStatus status);

    List<Booking> findByBookedByAndStatus(User user, BookingStatus status);

    /**
     * Core double-booking check: finds any active bookings for a room
     * that overlap with the requested time window.
     */
    @Query("""
        SELECT b FROM Booking b
        WHERE b.room = :room
        AND b.status IN ('CONFIRMED', 'PENDING')
        AND b.startTime < :endTime
        AND b.endTime > :startTime
        AND (:excludeId IS NULL OR b.id <> :excludeId)
    """)
    List<Booking> findOverlappingBookings(
            @Param("room") Room room,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime,
            @Param("excludeId") Long excludeId);

    List<Booking> findByStartTimeBetween(LocalDateTime from, LocalDateTime to);

    @Query("""
        SELECT b FROM Booking b
        WHERE b.bookedBy = :user
        AND b.startTime BETWEEN :from AND :to
        ORDER BY b.startTime ASC
    """)
    List<Booking> findUserBookingsInRange(
            @Param("user") User user,
            @Param("from") LocalDateTime from,
            @Param("to") LocalDateTime to);

    long countByStatus(BookingStatus status);
}
