package com.scms.repository;

import com.scms.entity.Room;
import com.scms.enums.RoomType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {

    Optional<Room> findByRoomNumber(String roomNumber);

    boolean existsByRoomNumber(String roomNumber);

    List<Room> findByActiveTrue();

    List<Room> findByRoomTypeAndActiveTrue(RoomType roomType);

    List<Room> findByBuildingAndActiveTrue(String building);

    List<Room> findByCapacityGreaterThanEqualAndActiveTrue(int minCapacity);

    /**
     * Finds rooms that have NO confirmed/pending bookings overlapping the given time slot.
     * Core query for availability checking.
     */
    @Query("""
        SELECT r FROM Room r
        WHERE r.active = true
        AND r.id NOT IN (
            SELECT b.room.id FROM Booking b
            WHERE b.status IN ('CONFIRMED', 'PENDING')
            AND b.startTime < :endTime
            AND b.endTime > :startTime
        )
    """)
    List<Room> findAvailableRooms(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);

    /**
     * Analytics: returns rooms with their booking counts, ordered by popularity.
     */
    @Query("""
        SELECT r.roomName, r.roomNumber, COUNT(b) AS bookingCount
        FROM Room r
        LEFT JOIN r.bookings b
        WHERE b.status = 'CONFIRMED'
        GROUP BY r.id, r.roomName, r.roomNumber
        ORDER BY bookingCount DESC
    """)
    List<Object[]> findMostBookedRooms();
}
