package com.scms.service;

import com.scms.entity.User;
import com.scms.enums.NotificationType;

/**
 * Observer Pattern — Subject (Publisher) interface.
 * Services that generate events implement or use this to notify observers.
 */
public interface NotificationPublisher {

    void registerObserver(NotificationObserver observer);

    void removeObserver(NotificationObserver observer);

    void notifyObservers(NotificationType type, User recipient, String title,
                         String message, Long referenceId, String referenceType);
}
