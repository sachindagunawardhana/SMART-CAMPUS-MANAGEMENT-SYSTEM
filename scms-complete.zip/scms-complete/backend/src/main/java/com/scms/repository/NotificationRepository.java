package com.scms.repository;

import com.scms.entity.Notification;
import com.scms.entity.User;
import com.scms.enums.NotificationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    List<Notification> findByRecipientOrderByCreatedAtDesc(User recipient);

    List<Notification> findByRecipientAndReadFalseOrderByCreatedAtDesc(User recipient);

    long countByRecipientAndReadFalse(User recipient);

    List<Notification> findByRecipientAndType(User recipient, NotificationType type);

    @Modifying
    @Query("UPDATE Notification n SET n.read = true WHERE n.recipient = :user AND n.read = false")
    void markAllAsReadForUser(@Param("user") User user);
}
