package com.scms.service;

import com.scms.entity.User;
import com.scms.enums.NotificationType;

/**
 * Observer Pattern — Observer interface.
 * Any component that needs to react to system events implements this.
 */
public interface NotificationObserver {
    void onEvent(NotificationType type, User recipient, String title,
                 String message, Long referenceId, String referenceType);
}
