package com.scms.service.impl;

import com.scms.dto.BookingDto;
import com.scms.dto.RoomDto;
import com.scms.service.BookingService;
import com.scms.service.RoomService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Facade Pattern — Structural.
 *
 * BookingFacade provides a simplified, unified interface over the
 * complex subsystems of RoomService, BookingService, and NotificationService.
 *
 * Client code (e.g. Controller) calls one method on the Facade instead of
 * orchestrating multiple services directly — reducing coupling and hiding
 * internal complexity.
 *
 * Why Facade here?
 *  - "Check available rooms → create booking" is a multi-step workflow
 *    involving two services. Facade encapsulates the sequence.
 *  - Controllers remain thin and don't know about the orchestration.
 *  - Easy to add new steps (e.g. payment, approval) without changing callers.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class BookingFacade {

    private final RoomService   roomService;
    private final BookingService bookingService;

    /**
     * Full booking workflow:
     *  1. Validate room availability for the requested slot
     *  2. Return available rooms for the user to choose
     *  3. Create and confirm the booking
     *  4. Notification is handled internally by BookingService
     */
    public BookingDto.Response bookRoom(BookingDto.CreateRequest request) {
        log.debug("Facade: initiating booking workflow for roomId={}", request.getRoomId());

        // Step 1: Quick availability pre-check (throws if room is inactive/missing)
        roomService.getRoomEntityById(request.getRoomId());

        // Step 2: Delegate to BookingService (which handles double-booking + notifications)
        BookingDto.Response response = bookingService.createBooking(request);

        log.debug("Facade: booking workflow completed, bookingId={}", response.getId());
        return response;
    }

    /**
     * Simplified room search + availability in one call.
     */
    public List<RoomDto.Response> findAvailableRooms(RoomDto.AvailabilityRequest request) {
        log.debug("Facade: finding available rooms from {} to {}",
                request.getStartTime(), request.getEndTime());
        return roomService.getAvailableRoomsFiltered(request);
    }

    /**
     * Cancel a booking — delegates to BookingService.
     */
    public BookingDto.Response cancelBooking(Long bookingId, BookingDto.CancelRequest request) {
        log.debug("Facade: cancelling bookingId={}", bookingId);
        return bookingService.cancelBooking(bookingId, request);
    }
}
