package com.scms.controller;

import com.scms.dto.MaintenanceDto;
import com.scms.service.MaintenanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Maintenance Request REST API.
 */
@RestController
@RequestMapping("/api/maintenance")
@RequiredArgsConstructor
public class MaintenanceController {

    private final MaintenanceService maintenanceService;

    /**
     * POST /api/maintenance
     * Any authenticated user can submit a maintenance request.
     */
    @PostMapping
    public ResponseEntity<MaintenanceDto.Response> createRequest(
            @Valid @RequestBody MaintenanceDto.CreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(maintenanceService.createRequest(request));
    }

    /**
     * PUT /api/maintenance/{id}/assign
     * Admin assigns request to a staff member.
     */
    @PutMapping("/{requestId}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<MaintenanceDto.Response> assignRequest(
            @PathVariable Long requestId,
            @Valid @RequestBody MaintenanceDto.AssignRequest request) {
        return ResponseEntity.ok(maintenanceService.assignRequest(requestId, request));
    }

    /**
     * PATCH /api/maintenance/{id}/status
     * Assignee or Admin updates the request status.
     */
    @PatchMapping("/{requestId}/status")
    public ResponseEntity<MaintenanceDto.Response> updateStatus(
            @PathVariable Long requestId,
            @Valid @RequestBody MaintenanceDto.UpdateStatusRequest request) {
        return ResponseEntity.ok(maintenanceService.updateStatus(requestId, request));
    }

    /**
     * GET /api/maintenance
     * Admin sees all requests.
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<MaintenanceDto.Response>> getAllRequests() {
        return ResponseEntity.ok(maintenanceService.getAllRequests());
    }

    /**
     * GET /api/maintenance/my
     * Current user's submitted requests.
     */
    @GetMapping("/my")
    public ResponseEntity<List<MaintenanceDto.Response>> getMyRequests() {
        return ResponseEntity.ok(maintenanceService.getMyRequests());
    }

    /**
     * GET /api/maintenance/assigned
     * Staff member sees requests assigned to them.
     */
    @GetMapping("/assigned")
    @PreAuthorize("hasAnyRole('ADMIN','STAFF')")
    public ResponseEntity<List<MaintenanceDto.Response>> getAssignedToMe() {
        return ResponseEntity.ok(maintenanceService.getAssignedToMe());
    }

    /**
     * GET /api/maintenance/{id}
     */
    @GetMapping("/{requestId}")
    public ResponseEntity<MaintenanceDto.Response> getById(@PathVariable Long requestId) {
        return ResponseEntity.ok(maintenanceService.getById(requestId));
    }
}
