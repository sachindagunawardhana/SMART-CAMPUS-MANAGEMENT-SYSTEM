package com.scms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when a booking violates business rules
 * (e.g., double booking, booking inactive room, invalid time range).
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class InvalidBookingException extends RuntimeException {

    private final String field;

    public InvalidBookingException(String message) {
        super(message);
        this.field = null;
    }

    public InvalidBookingException(String field, String message) {
        super(message);
        this.field = field;
    }

    public String getField() {
        return field;
    }
}
