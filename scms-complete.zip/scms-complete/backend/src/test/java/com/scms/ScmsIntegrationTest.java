package com.scms;

import com.scms.dto.AuthDto;
import com.scms.dto.RoomDto;
import com.scms.enums.RoomType;
import com.scms.service.UserService;
import com.scms.service.impl.RoomServiceImpl;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.*;

/**
 * Integration test — loads full Spring context with H2 in-memory DB.
 * Tests the actual wiring between Service → Repository layers.
 */
@SpringBootTest
@ActiveProfiles("test")
@Transactional
@DisplayName("SCMS Integration Tests")
class ScmsIntegrationTest {

    @Autowired private UserService   userService;
    @Autowired private RoomServiceImpl roomService;

    // ── TC01: User registration and retrieval ──────────────────────────────

    @Test
    @DisplayName("IT01 - Should register a student and retrieve by email")
    void shouldRegisterAndRetrieveStudent() {
        AuthDto.RegisterRequest req = new AuthDto.RegisterRequest();
        req.setFirstName("Integration");
        req.setLastName("Tester");
        req.setEmail("it.tester@scms.com");
        req.setPassword("Test@123");
        req.setRole("STUDENT");
        req.setStudentId("IT001");
        req.setFaculty("Testing");
        req.setYearOfStudy(1);

        var user = userService.registerUser(req);

        assertThat(user.getId()).isNotNull();
        assertThat(user.getEmail()).isEqualTo("it.tester@scms.com");

        var found = userService.getUserByEmail("it.tester@scms.com");
        assertThat(found.getFullName()).isEqualTo("Integration Tester");
    }

    // ── TC02: Room creation ────────────────────────────────────────────────

    @Test
    @DisplayName("IT02 - Should create a room and retrieve it")
    void shouldCreateAndRetrieveRoom() {
        RoomDto.CreateRequest req = new RoomDto.CreateRequest();
        req.setRoomNumber("IT101");
        req.setRoomName("Integration Test Room");
        req.setRoomType(RoomType.SEMINAR_ROOM);
        req.setCapacity(20);
        req.setBuilding("Test Block");

        RoomDto.Response created = roomService.createRoom(req);

        assertThat(created.getId()).isNotNull();
        assertThat(created.getRoomNumber()).isEqualTo("IT101");
        assertThat(created.isActive()).isTrue();

        RoomDto.Response fetched = roomService.getRoomById(created.getId());
        assertThat(fetched.getRoomName()).isEqualTo("Integration Test Room");
    }

    // ── TC03: Duplicate user registration ─────────────────────────────────

    @Test
    @DisplayName("IT03 - Should throw DuplicateDataException for duplicate email")
    void shouldThrowOnDuplicateEmail() {
        AuthDto.RegisterRequest req = new AuthDto.RegisterRequest();
        req.setFirstName("Dup"); req.setLastName("User");
        req.setEmail("dup@scms.com"); req.setPassword("Dup@123");
        req.setRole("STUDENT"); req.setStudentId("DUP001");
        req.setFaculty("CS"); req.setYearOfStudy(1);
        userService.registerUser(req);

        // Second registration with same email
        assertThatThrownBy(() -> userService.registerUser(req))
                .isInstanceOf(com.scms.exception.DuplicateDataException.class);
    }
}
