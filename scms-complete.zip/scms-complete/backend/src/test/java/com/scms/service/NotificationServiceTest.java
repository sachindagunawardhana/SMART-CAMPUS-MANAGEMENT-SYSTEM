package com.scms.service;

import com.scms.dto.NotificationDto;
import com.scms.entity.*;
import com.scms.enums.NotificationType;
import com.scms.enums.UserRole;
import com.scms.exception.UnauthorizedAccessException;
import com.scms.repository.NotificationRepository;
import com.scms.service.impl.NotificationServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for NotificationServiceImpl (Observer pattern).
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("NotificationService Unit Tests")
class NotificationServiceTest {

    @Mock private NotificationRepository notificationRepository;
    @Mock private UserService            userService;

    @InjectMocks
    private NotificationServiceImpl notificationService;

    private Student testStudent;
    private Notification testNotification;

    @BeforeEach
    void setUp() {
        testStudent = new Student("Alice", "Doe", "alice@scms.com",
                "pwd", "STU001", "CS", 2);
        testStudent.setId(1L);
        testStudent.setRole(UserRole.STUDENT);

        testNotification = Notification.builder()
                .id(100L)
                .title("Test Notification")
                .message("This is a test")
                .type(NotificationType.BOOKING_CONFIRMED)
                .recipient(testStudent)
                .read(false)
                .createdAt(LocalDateTime.now())
                .build();
    }

    // ── TC01: Notification is persisted on event ───────────────────────────

    @Test
    @DisplayName("TC01 - onEvent should persist notification to DB")
    void onEventShouldPersistNotification() {
        when(notificationRepository.save(any(Notification.class)))
                .thenReturn(testNotification);

        notificationService.onEvent(
                NotificationType.BOOKING_CONFIRMED, testStudent,
                "Booking Confirmed", "Your booking is confirmed.",
                1L, "BOOKING");

        verify(notificationRepository).save(any(Notification.class));
    }

    // ── TC02: Get unread notifications ────────────────────────────────────

    @Test
    @DisplayName("TC02 - Should return only unread notifications for current user")
    void shouldReturnUnreadNotificationsForCurrentUser() {
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(notificationRepository.findByRecipientAndReadFalseOrderByCreatedAtDesc(testStudent))
                .thenReturn(List.of(testNotification));

        List<NotificationDto.Response> result = notificationService.getMyUnreadNotifications();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).isRead()).isFalse();
        assertThat(result.get(0).getTitle()).isEqualTo("Test Notification");
    }

    // ── TC03: Mark notification as read ───────────────────────────────────

    @Test
    @DisplayName("TC03 - Should mark notification as read")
    void shouldMarkNotificationAsRead() {
        when(notificationRepository.findById(100L)).thenReturn(Optional.of(testNotification));
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(notificationRepository.save(any())).thenReturn(testNotification);

        notificationService.markAsRead(100L);

        verify(notificationRepository).save(argThat(n -> n.isRead()));
    }

    // ── TC04: Cannot mark another user's notification ──────────────────────

    @Test
    @DisplayName("TC04 - Should throw UnauthorizedAccessException when marking another user's notification")
    void shouldNotMarkOtherUsersNotification() {
        Student otherStudent = new Student("Bob", "Other", "bob@scms.com",
                "pwd", "STU002", "Physics", 1);
        otherStudent.setId(99L);
        otherStudent.setRole(UserRole.STUDENT);

        when(notificationRepository.findById(100L)).thenReturn(Optional.of(testNotification));
        when(userService.getCurrentUser()).thenReturn(otherStudent);

        assertThatThrownBy(() -> notificationService.markAsRead(100L))
                .isInstanceOf(UnauthorizedAccessException.class);

        verify(notificationRepository, never()).save(any());
    }

    // ── TC05: Count unread ────────────────────────────────────────────────

    @Test
    @DisplayName("TC05 - Should return correct unread count for current user")
    void shouldReturnCorrectUnreadCount() {
        when(userService.getCurrentUser()).thenReturn(testStudent);
        when(notificationRepository.countByRecipientAndReadFalse(testStudent)).thenReturn(5L);

        long count = notificationService.countUnread();

        assertThat(count).isEqualTo(5L);
    }

    // ── TC06: Observer registration ───────────────────────────────────────

    @Test
    @DisplayName("TC06 - Should register and invoke additional observers")
    void shouldInvokeRegisteredObservers() {
        NotificationObserver mockObserver = mock(NotificationObserver.class);
        notificationService.registerObserver(mockObserver);

        when(notificationRepository.save(any())).thenReturn(testNotification);

        notificationService.notifyObservers(
                NotificationType.BOOKING_CONFIRMED, testStudent,
                "Test", "Msg", 1L, "BOOKING");

        // Observer may be invoked asynchronously; verify at least DB save happened
        verify(notificationRepository).save(any());
    }
}
