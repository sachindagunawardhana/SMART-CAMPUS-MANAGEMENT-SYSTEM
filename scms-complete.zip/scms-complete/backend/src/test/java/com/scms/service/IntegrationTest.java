package com.scms.service;

import com.scms.SmartCampusManagementApplication;
import com.scms.dto.AuthDto;
import com.scms.entity.Room;
import com.scms.enums.RoomType;
import com.scms.repository.RoomRepository;
import com.scms.repository.UserRepository;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.*;

/**
 * Spring Integration Tests — loads the full application context with H2.
 * Tests real bean wiring, JPA, and service interactions end-to-end.
 */
@SpringBootTest(classes = SmartCampusManagementApplication.class)
@ActiveProfiles("test")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("Integration Tests — UserService + RoomService")
class IntegrationTest {

    @Autowired private UserService    userService;
    @Autowired private RoomService    roomService;
    @Autowired private UserRepository userRepository;
    @Autowired private RoomRepository roomRepository;

    // ── TEST 1: User registration persists to DB ───────────────────────────

    @Test
    @Order(1)
    @Transactional
    @DisplayName("✅ Integration: register user persists to H2 database")
    void integration_RegisterUser_PersistedToDb() {
        long before = userRepository.count();

        AuthDto.RegisterRequest req = new AuthDto.RegisterRequest();
        req.setFirstName("Integration");
        req.setLastName("Test");
        req.setEmail("integration_" + System.currentTimeMillis() + "@test.com");
        req.setPassword("Test@123");
        req.setRole("STUDENT");
        req.setStudentId("ITEST001");
        req.setFaculty("Engineering");
        req.setYearOfStudy(1);

        userService.registerUser(req);

        assertThat(userRepository.count()).isGreaterThan(before);
    }

    // ── TEST 2: Room persists and can be retrieved ──────────────────────────

    @Test
    @Order(2)
    @Transactional
    @DisplayName("✅ Integration: room saved to DB is retrievable by ID")
    void integration_Room_SaveAndRetrieve() {
        Room room = roomRepository.save(Room.builder()
                .roomNumber("INT-TEST-" + System.currentTimeMillis())
                .roomName("Integration Test Room")
                .roomType(RoomType.STUDY_ROOM)
                .capacity(10)
                .active(true)
                .build());

        assertThat(room.getId()).isNotNull();

        var retrieved = roomService.getRoomById(room.getId());
        assertThat(retrieved.getRoomName()).isEqualTo("Integration Test Room");
        assertThat(retrieved.isActive()).isTrue();
    }

    // ── TEST 3: Duplicate email registration fails ─────────────────────────

    @Test
    @Order(3)
    @DisplayName("🚫 Integration: duplicate email throws DuplicateDataException")
    void integration_DuplicateEmail_ThrowsException() {
        String uniqueEmail = "dup_" + System.currentTimeMillis() + "@test.com";

        AuthDto.RegisterRequest first = buildStudentRequest(uniqueEmail, "UNIQ001");
        AuthDto.RegisterRequest second = buildStudentRequest(uniqueEmail, "UNIQ002");

        userService.registerUser(first);

        assertThatThrownBy(() -> userService.registerUser(second))
                .isInstanceOf(com.scms.exception.DuplicateDataException.class);
    }

    private AuthDto.RegisterRequest buildStudentRequest(String email, String studentId) {
        AuthDto.RegisterRequest req = new AuthDto.RegisterRequest();
        req.setFirstName("Test");
        req.setLastName("User");
        req.setEmail(email);
        req.setPassword("Test@123");
        req.setRole("STUDENT");
        req.setStudentId(studentId);
        req.setFaculty("Science");
        req.setYearOfStudy(1);
        return req;
    }
}
