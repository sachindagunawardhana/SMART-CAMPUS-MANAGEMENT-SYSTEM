package com.scms.service;

import com.scms.dto.RoomDto;
import com.scms.entity.Room;
import com.scms.enums.RoomType;
import com.scms.exception.DuplicateDataException;
import com.scms.exception.ResourceNotFoundException;
import com.scms.repository.RoomRepository;
import com.scms.service.impl.RoomServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("RoomService Tests")
class RoomServiceImplTest {

    @Mock private RoomRepository roomRepository;

    @InjectMocks
    private RoomServiceImpl roomService;

    // ── TEST 1: Create room ────────────────────────────────────────────────

    @Test
    @DisplayName("✅ Should create room successfully")
    void createRoom_Success() {
        RoomDto.CreateRequest req = new RoomDto.CreateRequest();
        req.setRoomNumber("LH-201");
        req.setRoomName("New Lecture Hall");
        req.setRoomType(RoomType.LECTURE_HALL);
        req.setCapacity(100);
        req.setBuilding("Block D");
        req.setHasProjector(true);

        Room saved = Room.builder().id(1L).roomNumber("LH-201")
                .roomName("New Lecture Hall").roomType(RoomType.LECTURE_HALL)
                .capacity(100).building("Block D").active(true).build();

        given(roomRepository.existsByRoomNumber("LH-201")).willReturn(false);
        given(roomRepository.save(any(Room.class))).willReturn(saved);

        RoomDto.Response response = roomService.createRoom(req);

        assertThat(response.getRoomNumber()).isEqualTo("LH-201");
        assertThat(response.isActive()).isTrue();
        verify(roomRepository).save(any(Room.class));
    }

    // ── TEST 2: Duplicate room number ──────────────────────────────────────

    @Test
    @DisplayName("🚫 Should throw DuplicateDataException for duplicate room number")
    void createRoom_Duplicate_ThrowsException() {
        RoomDto.CreateRequest req = new RoomDto.CreateRequest();
        req.setRoomNumber("LH-101");
        req.setRoomName("Another Hall");
        req.setRoomType(RoomType.LECTURE_HALL);
        req.setCapacity(50);

        given(roomRepository.existsByRoomNumber("LH-101")).willReturn(true);

        assertThatThrownBy(() -> roomService.createRoom(req))
                .isInstanceOf(DuplicateDataException.class)
                .hasMessageContaining("LH-101");

        verify(roomRepository, never()).save(any());
    }

    // ── TEST 3: Deactivate room ────────────────────────────────────────────

    @Test
    @DisplayName("✅ Should deactivate room")
    void deactivateRoom_Success() {
        Room room = Room.builder().id(1L).roomNumber("LH-101")
                .roomName("Hall").active(true).build();

        given(roomRepository.findById(1L)).willReturn(Optional.of(room));
        given(roomRepository.save(any())).willAnswer(inv -> inv.getArgument(0));

        roomService.deactivateRoom(1L);

        assertThat(room.isActive()).isFalse();
        verify(roomRepository).save(room);
    }

    // ── TEST 4: Get all active rooms ───────────────────────────────────────

    @Test
    @DisplayName("✅ Should return all active rooms")
    void getActiveRooms_ReturnsOnlyActiveRooms() {
        Room active   = Room.builder().id(1L).roomNumber("A").roomType(RoomType.STUDY_ROOM)
                .roomName("Active").capacity(10).active(true).build();
        Room inactive = Room.builder().id(2L).roomNumber("B").roomType(RoomType.STUDY_ROOM)
                .roomName("Inactive").capacity(5).active(false).build();

        given(roomRepository.findByActiveTrue()).willReturn(List.of(active));

        List<RoomDto.Response> result = roomService.getActiveRooms();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getRoomNumber()).isEqualTo("A");
    }

    // ── TEST 5: Room not found ─────────────────────────────────────────────

    @Test
    @DisplayName("🚫 Should throw ResourceNotFoundException for unknown room")
    void getRoomById_NotFound_ThrowsException() {
        given(roomRepository.findById(999L)).willReturn(Optional.empty());

        assertThatThrownBy(() -> roomService.getRoomById(999L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("999");
    }
}
