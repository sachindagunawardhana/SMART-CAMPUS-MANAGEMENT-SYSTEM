package com.scms.service;

import com.scms.dto.RoomDto;
import com.scms.entity.Room;
import com.scms.enums.RoomType;
import com.scms.exception.DuplicateDataException;
import com.scms.exception.ResourceNotFoundException;
import com.scms.repository.RoomRepository;
import com.scms.service.impl.RoomServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for RoomServiceImpl.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("RoomService Unit Tests")
class RoomServiceTest {

    @Mock private RoomRepository roomRepository;

    @InjectMocks
    private RoomServiceImpl roomService;

    private Room testRoom;

    @BeforeEach
    void setUp() {
        testRoom = Room.builder()
                .id(1L)
                .roomNumber("A101")
                .roomName("Main Hall")
                .roomType(RoomType.LECTURE_HALL)
                .capacity(100)
                .building("Block A")
                .floorNumber(1)
                .active(true)
                .build();
    }

    // ── TC01: Create room ─────────────────────────────────────────────────

    @Test
    @DisplayName("TC01 - Should create room successfully")
    void shouldCreateRoomSuccessfully() {
        when(roomRepository.existsByRoomNumber("A101")).thenReturn(false);
        when(roomRepository.save(any(Room.class))).thenReturn(testRoom);

        RoomDto.CreateRequest req = new RoomDto.CreateRequest();
        req.setRoomNumber("A101");
        req.setRoomName("Main Hall");
        req.setRoomType(RoomType.LECTURE_HALL);
        req.setCapacity(100);
        req.setBuilding("Block A");
        req.setFloorNumber(1);

        RoomDto.Response result = roomService.createRoom(req);

        assertThat(result).isNotNull();
        assertThat(result.getRoomNumber()).isEqualTo("A101");
        assertThat(result.isActive()).isTrue();
    }

    // ── TC02: Duplicate room number ───────────────────────────────────────

    @Test
    @DisplayName("TC02 - Should throw DuplicateDataException for duplicate room number")
    void shouldThrowOnDuplicateRoomNumber() {
        when(roomRepository.existsByRoomNumber("A101")).thenReturn(true);

        RoomDto.CreateRequest req = new RoomDto.CreateRequest();
        req.setRoomNumber("A101");
        req.setRoomName("Duplicate");
        req.setRoomType(RoomType.LECTURE_HALL);
        req.setCapacity(50);

        assertThatThrownBy(() -> roomService.createRoom(req))
                .isInstanceOf(DuplicateDataException.class);

        verify(roomRepository, never()).save(any());
    }

    // ── TC03: Get room by ID ──────────────────────────────────────────────

    @Test
    @DisplayName("TC03 - Should return room by valid ID")
    void shouldReturnRoomById() {
        when(roomRepository.findById(1L)).thenReturn(Optional.of(testRoom));

        RoomDto.Response result = roomService.getRoomById(1L);

        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getRoomName()).isEqualTo("Main Hall");
    }

    // ── TC04: Room not found ──────────────────────────────────────────────

    @Test
    @DisplayName("TC04 - Should throw ResourceNotFoundException for invalid room ID")
    void shouldThrowWhenRoomNotFound() {
        when(roomRepository.findById(999L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> roomService.getRoomById(999L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("999");
    }

    // ── TC05: Deactivate room ─────────────────────────────────────────────

    @Test
    @DisplayName("TC05 - Should deactivate an active room")
    void shouldDeactivateRoom() {
        when(roomRepository.findById(1L)).thenReturn(Optional.of(testRoom));
        when(roomRepository.save(any(Room.class))).thenReturn(testRoom);

        roomService.deactivateRoom(1L);

        verify(roomRepository).save(argThat(r -> !r.isActive()));
    }

    // ── TC06: Get all active rooms ────────────────────────────────────────

    @Test
    @DisplayName("TC06 - Should return all active rooms")
    void shouldReturnAllActiveRooms() {
        when(roomRepository.findByActiveTrue()).thenReturn(List.of(testRoom));

        List<RoomDto.Response> result = roomService.getActiveRooms();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).isActive()).isTrue();
    }
}
