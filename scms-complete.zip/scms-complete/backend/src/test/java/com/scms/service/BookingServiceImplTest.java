package com.scms.service;

import com.scms.dto.BookingDto;
import com.scms.entity.*;
import com.scms.enums.*;
import com.scms.exception.InvalidBookingException;
import com.scms.exception.UnauthorizedAccessException;
import com.scms.repository.BookingRepository;
import com.scms.service.impl.BookingServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.*;

/**
 * Unit tests for BookingServiceImpl.
 * Covers: normal booking, double-booking, cancellation, exceptions.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("BookingService Tests")
class BookingServiceImplTest {

    @Mock private BookingRepository   bookingRepository;
    @Mock private RoomService         roomService;
    @Mock private UserService         userService;
    @Mock private NotificationService notificationService;

    @InjectMocks
    private BookingServiceImpl bookingService;

    // ── Test fixtures ──────────────────────────────────────────────────────

    private Room      testRoom;
    private User      testStudent;
    private User      testAdmin;
    private LocalDateTime futureStart;
    private LocalDateTime futureEnd;

    @BeforeEach
    void setUp() {
        testRoom = Room.builder()
                .id(1L)
                .roomNumber("LH-101")
                .roomName("Main Lecture Hall")
                .roomType(RoomType.LECTURE_HALL)
                .capacity(200)
                .active(true)
                .build();

        testStudent = new Student("Charlie", "Student", "student@scms.com",
                "encoded", "STU001", "CS", 2);
        testStudent.setId(10L);
        ((Student) testStudent).setRole(UserRole.STUDENT);

        testAdmin = new Admin("Alice", "Admin", "admin@scms.com",
                "encoded", "IT");
        testAdmin.setId(1L);
        ((Admin) testAdmin).setRole(UserRole.ADMIN);

        futureStart = LocalDateTime.now().plusDays(1).withHour(9).withMinute(0);
        futureEnd   = futureStart.plusHours(2);
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 1 — Successful booking creation
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("✅ Should create booking successfully when room is free")
    void createBooking_Success() {
        // Arrange
        BookingDto.CreateRequest req = buildCreateRequest(1L, futureStart, futureEnd);

        given(roomService.getRoomEntityById(1L)).willReturn(testRoom);
        given(userService.getCurrentUser()).willReturn(testStudent);
        given(bookingRepository.findOverlappingBookings(
                any(), any(), any(), any())).willReturn(Collections.emptyList());

        Booking savedBooking = Booking.builder()
                .id(100L)
                .room(testRoom)
                .bookedBy(testStudent)
                .startTime(futureStart)
                .endTime(futureEnd)
                .purpose("Lecture")
                .status(BookingStatus.CONFIRMED)
                .build();

        given(bookingRepository.save(any(Booking.class))).willReturn(savedBooking);

        // Act
        BookingDto.Response response = bookingService.createBooking(req);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getRoomNumber()).isEqualTo("LH-101");
        assertThat(response.getStatus()).isEqualTo("CONFIRMED");
        verify(bookingRepository, atLeastOnce()).save(any(Booking.class));
        verify(notificationService).sendNotification(
                any(), anyString(), anyString(), any(), any(), any());
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 2 — Double booking prevention
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("🚫 Should throw InvalidBookingException on double booking")
    void createBooking_DoubleBooking_ThrowsException() {
        // Arrange
        BookingDto.CreateRequest req = buildCreateRequest(1L, futureStart, futureEnd);

        Booking existing = Booking.builder()
                .id(99L)
                .room(testRoom)
                .startTime(futureStart)
                .endTime(futureEnd)
                .status(BookingStatus.CONFIRMED)
                .build();

        given(roomService.getRoomEntityById(1L)).willReturn(testRoom);
        given(userService.getCurrentUser()).willReturn(testStudent);
        given(bookingRepository.findOverlappingBookings(
                any(), any(), any(), any())).willReturn(List.of(existing));

        // Act + Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("already booked");

        verify(bookingRepository, never()).save(any(Booking.class));
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 3 — Inactive room cannot be booked
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("🚫 Should throw InvalidBookingException when room is inactive")
    void createBooking_InactiveRoom_ThrowsException() {
        // Arrange
        testRoom.setActive(false);
        BookingDto.CreateRequest req = buildCreateRequest(1L, futureStart, futureEnd);

        given(roomService.getRoomEntityById(1L)).willReturn(testRoom);
        given(userService.getCurrentUser()).willReturn(testStudent);

        // Act + Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("not available");
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 4 — Past time slot rejection
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("🚫 Should throw InvalidBookingException for past time slot")
    void createBooking_PastTime_ThrowsException() {
        // Arrange — deliberately in the past
        LocalDateTime pastStart = LocalDateTime.now().minusDays(1);
        LocalDateTime pastEnd   = pastStart.plusHours(1);
        BookingDto.CreateRequest req = buildCreateRequest(1L, pastStart, pastEnd);

        given(roomService.getRoomEntityById(1L)).willReturn(testRoom);
        given(userService.getCurrentUser()).willReturn(testStudent);

        // Act + Assert
        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("past");
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 5 — Cancellation by owner succeeds
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("✅ Should cancel booking when requested by owner")
    void cancelBooking_ByOwner_Success() {
        // Arrange
        Booking booking = Booking.builder()
                .id(100L)
                .room(testRoom)
                .bookedBy(testStudent)
                .startTime(futureStart)
                .endTime(futureEnd)
                .status(BookingStatus.CONFIRMED)
                .build();

        BookingDto.CancelRequest cancelReq = new BookingDto.CancelRequest();
        cancelReq.setReason("Schedule conflict");

        given(bookingRepository.findById(100L)).willReturn(Optional.of(booking));
        given(userService.getCurrentUser()).willReturn(testStudent);
        given(bookingRepository.save(any())).willReturn(booking);

        // Act
        BookingDto.Response response = bookingService.cancelBooking(100L, cancelReq);

        // Assert
        assertThat(response).isNotNull();
        verify(bookingRepository).save(argThat(b ->
                b.getStatus() == BookingStatus.CANCELLED));
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 6 — Cancellation by non-owner NON-admin fails
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("🚫 Should throw UnauthorizedAccessException when non-owner tries to cancel")
    void cancelBooking_NonOwner_ThrowsException() {
        // Arrange — booking belongs to testStudent, but testAdmin is a different user here
        // We simulate another student trying to cancel
        User otherStudent = new Student("Dave", "Other", "dave@scms.com",
                "enc", "STU999", "Law", 1);
        otherStudent.setId(99L);
        ((Student) otherStudent).setRole(UserRole.STUDENT);

        Booking booking = Booking.builder()
                .id(100L)
                .room(testRoom)
                .bookedBy(testStudent)   // owned by testStudent
                .startTime(futureStart)
                .endTime(futureEnd)
                .status(BookingStatus.CONFIRMED)
                .build();

        BookingDto.CancelRequest cancelReq = new BookingDto.CancelRequest();
        cancelReq.setReason("I don't want it");

        given(bookingRepository.findById(100L)).willReturn(Optional.of(booking));
        given(userService.getCurrentUser()).willReturn(otherStudent); // wrong user

        // Act + Assert
        assertThatThrownBy(() -> bookingService.cancelBooking(100L, cancelReq))
                .isInstanceOf(UnauthorizedAccessException.class);

        verify(bookingRepository, never()).save(any());
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 7 — Intentionally failing test (demonstrates test coverage)
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("❌ INTENTIONAL FAIL — capacity check not enforced (known bug)")
    void createBooking_ExceedsCapacity_ShouldThrow_ButDoesNot() {
        // This test documents a known gap:
        // If attendeesCount > capacity, an exception should be thrown.
        // We intentionally assert the WRONG outcome to mark this as a failing test.

        BookingDto.CreateRequest req = buildCreateRequest(1L, futureStart, futureEnd);
        req.setAttendeesCount(999); // room capacity is only 200

        given(roomService.getRoomEntityById(1L)).willReturn(testRoom);
        given(userService.getCurrentUser()).willReturn(testStudent);
        given(bookingRepository.findOverlappingBookings(
                any(), any(), any(), any())).willReturn(Collections.emptyList());

        Booking savedBooking = Booking.builder()
                .id(100L).room(testRoom).bookedBy(testStudent)
                .startTime(futureStart).endTime(futureEnd)
                .status(BookingStatus.CONFIRMED).build();
        given(bookingRepository.save(any())).willReturn(savedBooking);

        // BUG ASSERTION: we expect NO exception here — but the capacity check
        // in the real code DOES throw one. This test is intentionally failing
        // to demonstrate test-driven bug tracking.
        assertThatNoException()
                .as("BUG: capacity validation should be skipped — but it isn't")
                .isThrownBy(() -> bookingService.createBooking(req));
        // ^ This line WILL fail, proving the code correctly enforces capacity.
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEST 8 — End time before start time
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("🚫 Should throw when end time is before start time")
    void createBooking_InvalidTimeRange_ThrowsException() {
        LocalDateTime start = LocalDateTime.now().plusDays(1).withHour(10);
        LocalDateTime end   = start.minusHours(1); // end BEFORE start

        BookingDto.CreateRequest req = buildCreateRequest(1L, start, end);

        given(roomService.getRoomEntityById(1L)).willReturn(testRoom);
        given(userService.getCurrentUser()).willReturn(testStudent);

        assertThatThrownBy(() -> bookingService.createBooking(req))
                .isInstanceOf(InvalidBookingException.class)
                .hasMessageContaining("before end time");
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private BookingDto.CreateRequest buildCreateRequest(
            Long roomId, LocalDateTime start, LocalDateTime end) {
        BookingDto.CreateRequest req = new BookingDto.CreateRequest();
        req.setRoomId(roomId);
        req.setStartTime(start);
        req.setEndTime(end);
        req.setPurpose("Test purpose");
        req.setAttendeesCount(10);
        return req;
    }
}
